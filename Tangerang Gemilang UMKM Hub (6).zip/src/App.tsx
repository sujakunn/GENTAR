import { HashRouter, Route, Routes } from 'react-router'
import HomePage from './pages/Home'
import AboutPage from './pages/About'
import MarketplacePage from './pages/Marketplace'
import CommunityPage from './pages/Community'
import TrainingPage from './pages/Training'
import TourismPage from './pages/TourismPage'
import AuthPage from './pages/AuthPage'
import CartPage from './pages/CartPage'
import ProfilePage from './pages/ProfilePage'
import DashboardPage from './pages/DashboardPage'
import OrdersPage from './pages/OrdersPage'
import ProductsPage from './pages/ProductsPage'
import NotificationsPage from './pages/NotificationsPage'
import MessagesPage from './pages/MessagesPage'
import CheckoutPage from './pages/CheckoutPage'
import PaymentStatusPage from './pages/PaymentStatusPage'

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/marketplace" element={<MarketplacePage />} />
        <Route path="/community" element={<CommunityPage />} />
        <Route path="/training" element={<TrainingPage />} />
        <Route path="/tourism" element={<TourismPage />} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/messages" element={<MessagesPage />} />
        <Route path="/payment/:transactionId" element={<PaymentStatusPage />} />
      </Routes>
    </HashRouter>
  )
}
