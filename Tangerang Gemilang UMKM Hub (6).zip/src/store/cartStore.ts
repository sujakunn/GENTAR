/**
 * Shopping cart store using Zustand for state management
 * Handles cart operations, items, and checkout process
 */

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
  seller: string
  category: string
}

interface CartState {
  items: CartItem[]
  totalItems: number
  totalPrice: number
  addItem: (item: Omit<CartItem, 'quantity'>) => void
  removeItem: (itemId: string) => void
  updateQuantity: (itemId: string, quantity: number) => void
  clearCart: () => void
  getCartTotal: () => { items: number; price: number }
  applyPromoCode: (code: string) => { success: boolean; discount: number; message: string }
  calculateShipping: (address: string) => { cost: number; estimatedDays: number }
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      totalItems: 0,
      totalPrice: 0,

      addItem: (item) => {
        const items = get().items
        const existingItem = items.find(i => i.id === item.id)

        if (existingItem) {
          const updatedItems = items.map(i =>
            i.id === item.id
              ? { ...i, quantity: i.quantity + 1 }
              : i
          )
          set({ items: updatedItems })
        } else {
          const newItem: CartItem = { ...item, quantity: 1 }
          set({ items: [...items, newItem] })
        }

        // Update totals
        const totals = get().getCartTotal()
        set({
          totalItems: totals.items,
          totalPrice: totals.price
        })
      },

      removeItem: (itemId) => {
        const items = get().items.filter(item => item.id !== itemId)
        set({ items })
        
        // Update totals
        const totals = get().getCartTotal()
        set({
          totalItems: totals.items,
          totalPrice: totals.price
        })
      },

      updateQuantity: (itemId, quantity) => {
        if (quantity <= 0) {
          get().removeItem(itemId)
          return
        }

        const items = get().items.map(item =>
          item.id === itemId
            ? { ...item, quantity }
            : item
        )
        set({ items })
        
        // Update totals
        const totals = get().getCartTotal()
        set({
          totalItems: totals.items,
          totalPrice: totals.price
        })
      },

      clearCart: () => {
        set({ 
          items: [], 
          totalItems: 0, 
          totalPrice: 0 
        })
      },

      getCartTotal: () => {
        const items = get().items
        const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
        const totalPrice = items.reduce((sum, item) => sum + (item.price * item.quantity), 0)
        
        // Update state totals
        set({ totalItems, totalPrice })
        
        return { items: totalItems, price: totalPrice }
      },

      applyPromoCode: (code: string) => {
        const promoCodes = {
          'UMKM10': { discount: 0.1, message: 'Diskon 10% berhasil diterapkan!' },
          'UMKM20': { discount: 0.2, message: 'Diskon 20% berhasil diterapkan!' },
          'WELCOME': { discount: 0.15, message: 'Diskon 15% untuk member baru!' }
        }
        
        const promo = promoCodes[code as keyof typeof promoCodes]
        
        if (promo) {
          return { success: true, discount: promo.discount, message: promo.message }
        }
        
        return { success: false, discount: 0, message: 'Kode promo tidak valid!' }
      },

      calculateShipping: (address: string) => {
        // Simple shipping calculation based on address
        const baseCost = 15000
        const jakartaAreas = ['jakarta', 'dki jakarta']
        const tangerangAreas = ['tangerang', 'kab. tangerang', 'kota tangerang']
        
        let cost = baseCost
        let estimatedDays = 3
        
        if (jakartaAreas.some(area => address.toLowerCase().includes(area))) {
          cost = 10000
          estimatedDays = 1
        } else if (tangerangAreas.some(area => address.toLowerCase().includes(area))) {
          cost = 12000
          estimatedDays = 2
        }
        
        return { cost, estimatedDays }
      }
    }),
    {
      name: 'cart-storage'
    }
  )
)