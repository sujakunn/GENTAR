/**
 * Product store using Zustand for state management
 * Handles product CRUD operations, filtering, and search
 */

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface Product {
  id: string
  name: string
  description: string
  price: number
  category: string
  image: string
  seller: string
  sellerId: string
  rating: number
  reviews: Review[]
  stock: number
  tags: string[]
  createdAt: string
  updatedAt: string
}

export interface Review {
  id: string
  userId: string
  userName: string
  rating: number
  comment: string
  createdAt: string
}

interface ProductState {
  products: Product[]
  filteredProducts: Product[]
  searchQuery: string
  selectedCategory: string
  priceRange: [number, number]
  sortBy: 'name' | 'price' | 'rating' | 'newest'
  sortOrder: 'asc' | 'desc'
  
  // Actions
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => void
  updateProduct: (id: string, updates: Partial<Product>) => void
  deleteProduct: (id: string) => void
  addReview: (productId: string, review: Omit<Review, 'id' | 'createdAt'>) => void
  setSearchQuery: (query: string) => void
  setSelectedCategory: (category: string) => void
  setPriceRange: (range: [number, number]) => void
  setSortBy: (sortBy: 'name' | 'price' | 'rating' | 'newest') => void
  setSortOrder: (order: 'asc' | 'desc') => void
  filterProducts: () => void
}

// Mock initial products
const initialProducts: Product[] = [
  {
    id: '1',
    name: 'Keripik Pisang Premium',
    description: 'Keripik pisang renyah dengan rasa original, dibuat dari pisang pilihan',
    price: 25000,
    category: 'Makanan',
    image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/765b0d9f-0a93-490a-9863-6f98ee6bc599.jpg',
    seller: 'UMKM Pisang Jaya',
    sellerId: '1',
    rating: 4.8,
    reviews: [],
    stock: 50,
    tags: ['snack', 'pisang', 'original'],
    createdAt: '2024-01-01',
    updatedAt: '2024-01-01'
  },
  {
    id: '2',
    name: 'Madu Hutan Murni',
    description: 'Madu alami dari hutan Tangerang, tanpa tambahan gula',
    price: 85000,
    category: 'Minuman',
    image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/63ce3461-f234-491b-8b25-1f1822b43655.jpg',
    seller: 'UMKM Madu Sejahtera',
    sellerId: '2',
    rating: 4.9,
    reviews: [],
    stock: 30,
    tags: ['madu', 'alami', 'kesehatan'],
    createdAt: '2024-01-02',
    updatedAt: '2024-01-02'
  },
  {
    id: '3',
    name: 'Tas Anyaman Bambu',
    description: 'Tas anyaman bambu eco-friendly, cocok untuk sehari-hari',
    price: 120000,
    category: 'Kerajinan',
    image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/dd8a27c6-d1f2-4c5b-977f-8c219309d3d1.jpg',
    seller: 'UMKM Bambu Kreatif',
    sellerId: '3',
    rating: 4.7,
    reviews: [],
    stock: 20,
    tags: ['tas', 'bambu', 'eco-friendly'],
    createdAt: '2024-01-03',
    updatedAt: '2024-01-03'
  }
]

export const useProductStore = create<ProductState>()(
  persist(
    (set, get) => ({
      products: initialProducts,
      filteredProducts: initialProducts,
      searchQuery: '',
      selectedCategory: 'Semua',
      priceRange: [0, 1000000],
      sortBy: 'newest',
      sortOrder: 'desc',

      addProduct: (productData) => {
        console.log('ProductStore - addProduct called with:', productData)
        const newProduct: Product = {
          ...productData,
          id: Date.now().toString(),
          createdAt: new Date().toISOString().split('T')[0],
          updatedAt: new Date().toISOString().split('T')[0]
        }
        
        console.log('Creating new product:', newProduct)
        
        set((state) => {
          const newProducts = [...state.products, newProduct]
          console.log('New products array:', newProducts)
          return { products: newProducts }
        })
        
        get().filterProducts()
        
        // Log for debugging
        console.log('Product added successfully:', newProduct)
        console.log('Current products:', get().products)
      },

      updateProduct: (id, updates) => {
        set((state) => ({
          products: state.products.map(product =>
            product.id === id
              ? { ...product, ...updates, updatedAt: new Date().toISOString().split('T')[0] }
              : product
          )
        }))
        
        get().filterProducts()
      },

      deleteProduct: (id) => {
        set((state) => ({
          products: state.products.filter(product => product.id !== id)
        }))
        
        get().filterProducts()
      },

      addReview: (productId, reviewData) => {
        const newReview: Review = {
          ...reviewData,
          id: Date.now().toString(),
          createdAt: new Date().toISOString().split('T')[0]
        }
        
        set((state) => ({
          products: state.products.map(product =>
            product.id === productId
              ? {
                  ...product,
                  reviews: [...product.reviews, newReview],
                  rating: calculateAverageRating([...product.reviews, newReview])
                }
              : product
          )
        }))
        
        get().filterProducts()
      },

      setSearchQuery: (query) => {
        set({ searchQuery: query })
        get().filterProducts()
      },

      setSelectedCategory: (category) => {
        set({ selectedCategory: category })
        get().filterProducts()
      },

      setPriceRange: (range) => {
        set({ priceRange: range })
        get().filterProducts()
      },

      setSortBy: (sortBy) => {
        set({ sortBy })
        get().filterProducts()
      },

      setSortOrder: (sortOrder) => {
        set({ sortOrder })
        get().filterProducts()
      },

      filterProducts: () => {
        const state = get()
        let filtered = [...state.products]

        // Filter by search query
        if (state.searchQuery) {
          filtered = filtered.filter(product =>
            product.name.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
            product.description.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
            product.tags.some(tag => tag.toLowerCase().includes(state.searchQuery.toLowerCase()))
          )
        }

        // Filter by category
        if (state.selectedCategory !== 'Semua') {
          filtered = filtered.filter(product => product.category === state.selectedCategory)
        }

        // Filter by price range
        filtered = filtered.filter(product =>
          product.price >= state.priceRange[0] && product.price <= state.priceRange[1]
        )

        // Sort products
        filtered.sort((a, b) => {
          let comparison = 0
          
          switch (state.sortBy) {
            case 'name':
              comparison = a.name.localeCompare(b.name)
              break
            case 'price':
              comparison = a.price - b.price
              break
            case 'rating':
              comparison = a.rating - b.rating
              break
            case 'newest':
              comparison = new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
              break
          }
          
          return state.sortOrder === 'asc' ? comparison : -comparison
        })

        set({ filteredProducts: filtered })
      }
    }),
    {
      name: 'product-storage'
    }
  )
)

// Helper function to calculate average rating
function calculateAverageRating(reviews: Review[]): number {
  if (reviews.length === 0) return 0
  const total = reviews.reduce((sum, review) => sum + review.rating, 0)
  return Math.round((total / reviews.length) * 10) / 10
}
