/**
 * Authentication store using Zustand for state management
 * Handles user authentication, registration, and profile management
 */

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface User {
  id: string
  name: string
  email: string
  phone: string
  businessName?: string
  businessType?: string
  address: string
  avatar?: string
  role: 'customer' | 'seller' | 'admin'
  joinedAt: string
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: Omit<User, 'id' | 'joinedAt'> & { password: string }) => Promise<boolean>
  logout: () => void
  updateProfile: (userData: Partial<User>) => Promise<boolean>
}

// Mock users database for demo
const mockUsers: User[] = [
  {
    id: '1',
    name: 'Ahmad Fauzi',
    email: 'ahmad@example.com',
    phone: '081234567890',
    businessName: 'Keripik Pisang Premium',
    businessType: 'Food',
    address: 'Tangerang, Banten',
    role: 'seller',
    joinedAt: '2023-01-15'
  },
  {
    id: '2',
    name: 'Siti Nurhaliza',
    email: 'siti@example.com',
    phone: '081234567891',
    businessName: 'Madu Hutan Murni',
    businessType: 'Beverage',
    address: 'Tangerang, Banten',
    role: 'seller',
    joinedAt: '2023-02-20'
  },
  {
    id: '3',
    name: 'Budi Santoso',
    email: 'budi@example.com',
    phone: '081234567892',
    address: 'Tangerang, Banten',
    role: 'customer',
    joinedAt: '2024-01-10'
  }
]

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (email: string, password: string) => {
        console.log('AuthStore - login called with:', { email, password })
        set({ isLoading: true })
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        const user = mockUsers.find(u => u.email === email)
        console.log('Found user:', user)
        
        if (user) {
          console.log('Login successful, setting user state')
          set({ 
            user, 
            isAuthenticated: true, 
            isLoading: false 
          })
          console.log('User state after login:', { user, isAuthenticated: true, isLoading: false })
          return true
        }
        
        console.log('Login failed - user not found')
        set({ isLoading: false })
        return false
      },

      register: async (userData: Omit<User, 'id' | 'joinedAt'> & { password: string }) => {
        set({ isLoading: true })
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        const newUser: User = {
          ...userData,
          id: Date.now().toString(),
          joinedAt: new Date().toISOString().split('T')[0]
        }
        
        mockUsers.push(newUser)
        
        set({ 
          user: newUser, 
          isAuthenticated: true, 
          isLoading: false 
        })
        return true
      },

      logout: () => {
        set({ 
          user: null, 
          isAuthenticated: false 
        })
      },

      updateProfile: async (userData: Partial<User>) => {
        set({ isLoading: true })
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 500))
        
        const currentUser = get().user
        if (currentUser) {
          const updatedUser = { ...currentUser, ...userData }
          set({ 
            user: updatedUser, 
            isLoading: false 
          })
          return true
        }
        
        set({ isLoading: false })
        return false
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ 
        user: state.user, 
        isAuthenticated: state.isAuthenticated 
      })
    }
  )
)