/**
 * Order store using Zustand for state management
 * Handles order creation, tracking, and management
 */

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { useCartStore } from './cartStore'
import { useAuthStore } from './authStore'

export interface OrderItem {
  productId: string
  productName: string
  productImage: string
  quantity: number
  price: number
  sellerId: string
  sellerName: string
  category: string
}

export interface ShippingAddress {
  name: string
  phone: string
  address: string
  city: string
  province: string
  postalCode: string
  notes?: string
}

export interface Order {
  id: string
  userId: string
  items: OrderItem[]
  subtotal: number
  shippingCost: number
  serviceFee: number
  totalAmount: number
  paymentMethod: string
  paymentStatus: 'pending' | 'paid' | 'failed' | 'refunded'
  orderStatus: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
  shippingAddress: ShippingAddress
  trackingNumber?: string
  estimatedDelivery?: string
  actualDelivery?: string
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface OrderStats {
  totalOrders: number
  totalRevenue: number
  averageOrderValue: number
  pendingOrders: number
  completedOrders: number
  cancelledOrders: number
}

interface OrderState {
  orders: Order[]
  currentOrder: Order | null
  orderStats: OrderStats
  isLoading: boolean
  
  // Actions
  createOrder: (shippingAddress: ShippingAddress, paymentMethod: string, notes?: string) => Promise<Order>
  updateOrderStatus: (orderId: string, status: Order['orderStatus']) => Promise<void>
  updatePaymentStatus: (orderId: string, status: Order['paymentStatus']) => Promise<void>
  addTrackingNumber: (orderId: string, trackingNumber: string) => Promise<void>
  getOrderById: (orderId: string) => Order | undefined
  getUserOrders: (userId: string) => Order[]
  getSellerOrders: (sellerId: string) => Order[]
  cancelOrder: (orderId: string, reason?: string) => Promise<void>
  calculateOrderStats: () => OrderStats
}

export const useOrderStore = create<OrderState>()(
  persist(
    (set, get) => ({
      orders: [],
      currentOrder: null,
      orderStats: {
        totalOrders: 0,
        totalRevenue: 0,
        averageOrderValue: 0,
        pendingOrders: 0,
        completedOrders: 0,
        cancelledOrders: 0
      },
      isLoading: false,

      createOrder: async (shippingAddress, paymentMethod, notes) => {
        set({ isLoading: true })
        
        try {
          const { items, totalPrice, clearCart } = useCartStore.getState()
          const { user } = useAuthStore.getState()
          
          if (!user) {
            throw new Error('User not authenticated')
          }
          
          if (items.length === 0) {
            throw new Error('Cart is empty')
          }
          
          // Calculate costs
          const subtotal = totalPrice
          const shippingCost = 15000 // Fixed shipping cost
          const serviceFee = 2000 // Fixed service fee
          const totalAmount = subtotal + shippingCost + serviceFee
          
          // Create order items
          const orderItems: OrderItem[] = items.map(item => ({
            productId: item.id,
            productName: item.name,
            productImage: item.image,
            quantity: item.quantity,
            price: item.price,
            sellerId: item.sellerId,
            sellerName: item.seller,
            category: item.category
          }))
          
          // Create order
          const order: Order = {
            id: `ORD-${Date.now()}`,
            userId: user.id,
            items: orderItems,
            subtotal,
            shippingCost,
            serviceFee,
            totalAmount,
            paymentMethod,
            paymentStatus: 'pending',
            orderStatus: 'pending',
            shippingAddress,
            notes,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          }
          
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 2000))
          
          set((state) => ({
            orders: [...state.orders, order],
            currentOrder: order,
            isLoading: false
          }))
          
          // Clear cart after successful order creation
          clearCart()
          
          return order
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      updateOrderStatus: async (orderId, status) => {
        set({ isLoading: true })
        
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 1000))
          
          set((state) => ({
            orders: state.orders.map(order =>
              order.id === orderId
                ? { 
                    ...order, 
                    orderStatus: status,
                    updatedAt: new Date().toISOString(),
                    ...(status === 'shipped' && {
                      trackingNumber: `TRK${Math.random().toString(36).substr(2, 10).toUpperCase()}`,
                      estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString()
                    }),
                    ...(status === 'delivered' && {
                      actualDelivery: new Date().toISOString()
                    })
                  }
                : order
            ),
            isLoading: false
          }))
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      updatePaymentStatus: async (orderId, status) => {
        set({ isLoading: true })
        
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 1000))
          
          set((state) => ({
            orders: state.orders.map(order =>
              order.id === orderId
                ? { 
                    ...order, 
                    paymentStatus: status,
                    updatedAt: new Date().toISOString()
                  }
                : order
            ),
            isLoading: false
          }))
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      addTrackingNumber: async (orderId, trackingNumber) => {
        set({ isLoading: true })
        
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 1000))
          
          set((state) => ({
            orders: state.orders.map(order =>
              order.id === orderId
                ? { 
                    ...order, 
                    trackingNumber,
                    orderStatus: 'shipped',
                    estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
                    updatedAt: new Date().toISOString()
                  }
                : order
            ),
            isLoading: false
          }))
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      getOrderById: (orderId) => {
        return get().orders.find(order => order.id === orderId)
      },

      getUserOrders: (userId) => {
        return get().orders
          .filter(order => order.userId === userId)
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      },

      getSellerOrders: (sellerId) => {
        return get().orders
          .filter(order => order.items.some(item => item.sellerId === sellerId))
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      },

      cancelOrder: async (orderId, reason) => {
        set({ isLoading: true })
        
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 1000))
          
          set((state) => ({
            orders: state.orders.map(order =>
              order.id === orderId
                ? { 
                    ...order, 
                    orderStatus: 'cancelled',
                    paymentStatus: 'refunded',
                    notes: reason ? `${order.notes} | Cancellation: ${reason}` : order.notes,
                    updatedAt: new Date().toISOString()
                  }
                : order
            ),
            isLoading: false
          }))
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      calculateOrderStats: () => {
        const orders = get().orders
        const totalOrders = orders.length
        const totalRevenue = orders.reduce((sum, order) => 
          order.paymentStatus === 'paid' ? sum + order.totalAmount : sum, 0
        )
        const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0
        const pendingOrders = orders.filter(order => order.orderStatus === 'pending').length
        const completedOrders = orders.filter(order => order.orderStatus === 'delivered').length
        const cancelledOrders = orders.filter(order => order.orderStatus === 'cancelled').length
        
        const stats: OrderStats = {
          totalOrders,
          totalRevenue,
          averageOrderValue,
          pendingOrders,
          completedOrders,
          cancelledOrders
        }
        
        set({ orderStats: stats })
        return stats
      }
    }),
    {
      name: 'order-storage'
    }
  )
)
