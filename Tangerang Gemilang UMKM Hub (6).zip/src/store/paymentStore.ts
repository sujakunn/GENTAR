/**
 * Payment store using Zustand for state management
 * Handles payment processing, methods, and transaction history
 */

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface PaymentMethod {
  id: string
  name: string
  type: 'bank_transfer' | 'e_wallet' | 'credit_card' | 'cod'
  icon: string
  enabled: boolean
  fee: number
}

export interface PaymentTransaction {
  id: string
  orderId: string
  amount: number
  paymentMethod: string
  status: 'pending' | 'processing' | 'success' | 'failed' | 'cancelled'
  transactionId?: string
  vaNumber?: string
  expiryDate?: string
  paymentUrl?: string
  createdAt: string
  updatedAt: string
}

export interface PaymentConfig {
  midtrans: {
    clientKey: string
    serverKey: string
    isProduction: boolean
  }
  enabledMethods: string[]
}

interface PaymentState {
  paymentMethods: PaymentMethod[]
  transactions: PaymentTransaction[]
  config: PaymentConfig
  currentTransaction: PaymentTransaction | null
  isLoading: boolean
  
  // Actions
  initializePayment: (orderId: string, amount: number, method: string) => Promise<PaymentTransaction>
  checkPaymentStatus: (transactionId: string) => Promise<void>
  cancelPayment: (transactionId: string) => Promise<void>
  getTransactionHistory: () => PaymentTransaction[]
  addPaymentMethod: (method: PaymentMethod) => void
  removePaymentMethod: (methodId: string) => void
  updatePaymentConfig: (config: Partial<PaymentConfig>) => void
  processPayment: (transactionId: string, paymentData: any) => Promise<PaymentTransaction>
  generateQRCode: (transactionId: string) => Promise<string>
  validatePayment: (transactionId: string, validationCode: string) => Promise<boolean>
}

const defaultPaymentMethods: PaymentMethod[] = [
  {
    id: 'bca_va',
    name: 'BCA Virtual Account',
    type: 'bank_transfer',
    icon: '🏦',
    enabled: true,
    fee: 5000
  },
  {
    id: 'mandiri_va',
    name: 'Mandiri Virtual Account',
    type: 'bank_transfer',
    icon: '🏦',
    enabled: true,
    fee: 5000
  },
  {
    id: 'bri_va',
    name: 'BRI Virtual Account',
    type: 'bank_transfer',
    icon: '🏦',
    enabled: true,
    fee: 5000
  },
  {
    id: 'gopay',
    name: 'GoPay',
    type: 'e_wallet',
    icon: '📱',
    enabled: true,
    fee: 2000
  },
  {
    id: 'ovo',
    name: 'OVO',
    type: 'e_wallet',
    icon: '📱',
    enabled: true,
    fee: 2000
  },
  {
    id: 'dana',
    name: 'DANA',
    type: 'e_wallet',
    icon: '📱',
    enabled: true,
    fee: 2000
  },
  {
    id: 'credit_card',
    name: 'Kartu Kredit',
    type: 'credit_card',
    icon: '💳',
    enabled: true,
    fee: 10000
  },
  {
    id: 'cod',
    name: 'COD (Bayar di Tempat)',
    type: 'cod',
    icon: '📦',
    enabled: true,
    fee: 0
  }
]

export const usePaymentStore = create<PaymentState>()(
  persist(
    (set, get) => ({
      paymentMethods: defaultPaymentMethods,
      transactions: [],
      config: {
        midtrans: {
          clientKey: 'SB-Mid-client-your-client-key',
          serverKey: 'SB-Mid-server-your-server-key',
          isProduction: false
        },
        enabledMethods: ['bca_va', 'mandiri_va', 'gopay', 'ovo', 'cod']
      },
      currentTransaction: null,
      isLoading: false,

      initializePayment: async (orderId, amount, method) => {
        console.log('PaymentStore - initializePayment called:', { orderId, amount, method })
        set({ isLoading: true })
        
        try {
          // Simulate API call to payment gateway
          await new Promise(resolve => setTimeout(resolve, 2000))
          
          const paymentMethod = get().paymentMethods.find(m => m.id === method)
          const totalAmount = amount + (paymentMethod?.fee || 0)
          
          const transaction: PaymentTransaction = {
            id: `TRX-${Date.now()}`,
            orderId,
            amount: totalAmount,
            paymentMethod: method,
            status: 'pending',
            transactionId: `TX-${Math.random().toString(36).substr(2, 9)}`,
            vaNumber: method.includes('_va') ? `${Math.floor(Math.random() * 10000000000)}` : undefined,
            expiryDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            paymentUrl: method === 'credit_card' ? `https://payment-gateway.com/pay/${orderId}` : undefined,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          }
          
          console.log('Creating transaction:', transaction)
          
          set((state) => {
            const newTransactions = [...state.transactions, transaction]
            console.log('New transactions array:', newTransactions)
            return {
              transactions: newTransactions,
              currentTransaction: transaction,
              isLoading: false
            }
          })
          
          console.log('Payment initialized successfully')
          console.log('Current transactions:', get().transactions)
          
          return transaction
        } catch (error) {
          console.error('Error in initializePayment:', error)
          set({ isLoading: false })
          throw error
        }
      },

      checkPaymentStatus: async (transactionId) => {
        set({ isLoading: true })
        
        try {
          // Simulate API call to check payment status
          await new Promise(resolve => setTimeout(resolve, 1000))
          
          set((state) => ({
            transactions: state.transactions.map(t => 
              t.id === transactionId 
                ? { ...t, status: Math.random() > 0.3 ? 'success' : 'pending', updatedAt: new Date().toISOString() }
                : t
            ),
            isLoading: false
          }))
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      cancelPayment: async (transactionId) => {
        set({ isLoading: true })
        
        try {
          // Simulate API call to cancel payment
          await new Promise(resolve => setTimeout(resolve, 1000))
          
          set((state) => ({
            transactions: state.transactions.map(t => 
              t.id === transactionId 
                ? { ...t, status: 'cancelled', updatedAt: new Date().toISOString() }
                : t
            ),
            currentTransaction: state.currentTransaction?.id === transactionId ? null : state.currentTransaction,
            isLoading: false
          }))
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      getTransactionHistory: () => {
        return get().transactions.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        )
      },

      addPaymentMethod: (method) => {
        set((state) => ({
          paymentMethods: [...state.paymentMethods, method]
        }))
      },

      removePaymentMethod: (methodId) => {
        set((state) => ({
          paymentMethods: state.paymentMethods.filter(m => m.id !== methodId)
        }))
      },

      updatePaymentConfig: (config) => {
        set((state) => ({
          config: { ...state.config, ...config }
        }))
      },

      processPayment: async (transactionId: string, paymentData: any) => {
        set({ isLoading: true })
        
        try {
          // Simulate payment processing
          await new Promise(resolve => setTimeout(resolve, 3000))
          
          set((state) => ({
            transactions: state.transactions.map(t => 
              t.id === transactionId
                ? { ...t, status: 'success', updatedAt: new Date().toISOString() }
                : t
            ),
            isLoading: false
          }))
          
          const updatedTransaction = get().transactions.find(t => t.id === transactionId)
          return updatedTransaction!
        } catch (error) {
          set({ isLoading: false })
          throw error
        }
      },

      generateQRCode: async (transactionId: string) => {
        const transaction = get().transactions.find(t => t.id === transactionId)
        if (!transaction) {
          throw new Error('Transaction not found')
        }
        
        // Generate QR code data (in real app, this would connect to payment gateway)
        const qrData = {
          transactionId: transaction.id,
          amount: transaction.amount,
          merchant: 'UMKM Tangerang Gemilang',
          timestamp: new Date().toISOString()
        }
        
        // Return base64 encoded QR code (mock)
        return `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==`
      },

      validatePayment: async (transactionId: string, validationCode: string) => {
        // Simulate payment validation
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        // Simple validation (in real app, this would check with payment gateway)
        const isValid = validationCode.length >= 6
        
        if (isValid) {
          set((state) => ({
            transactions: state.transactions.map(t => 
              t.id === transactionId
                ? { ...t, status: 'success', updatedAt: new Date().toISOString() }
                : t
            )
          }))
        }
        
        return isValid
      }
    }),
    {
      name: 'payment-storage'
    }
  )
)
