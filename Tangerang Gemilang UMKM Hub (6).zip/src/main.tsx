// Fix for Target is not defined error
if (typeof window !== 'undefined' && typeof (window as any).Target === 'undefined') {
  (window as any).Target = {};
}

// Global error handler
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    console.error('Global error caught:', event.error);
    event.preventDefault();
  });

  window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    event.preventDefault();
  });
}

import { createRoot } from 'react-dom/client'
import './shadcn.css'
import App from './App'

const root = createRoot(document.getElementById('app')!)
root.render(<App />)
