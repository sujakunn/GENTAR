/**
 * Product form component for adding and editing products
 * Includes validation and image upload functionality
 */

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, Plus, X, Upload } from 'lucide-react'
import { useProductStore, Product } from '@/store/productStore'
import { useAuthStore } from '@/store/authStore'

const productSchema = z.object({
  name: z.string().min(3, 'Nama produk minimal 3 karakter'),
  description: z.string().min(10, 'Deskripsi minimal 10 karakter'),
  price: z.number().min(1000, 'Harga minimal Rp 1.000'),
  category: z.string().min(1, 'Pilih kategori'),
  stock: z.number().min(1, 'Stok minimal 1'),
  tags: z.array(z.string()).optional()
})

type ProductFormData = z.infer<typeof productSchema>

interface ProductFormProps {
  product?: Product
  onSuccess?: () => void
}

export default function ProductForm({ product, onSuccess }: ProductFormProps) {
  const { user } = useAuthStore()
  const { addProduct, updateProduct } = useProductStore()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [tags, setTags] = useState<string[]>(product?.tags || [])
  const [newTag, setNewTag] = useState('')
  const [imagePreview, setImagePreview] = useState(product?.image || '')

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors }
  } = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: product?.name || '',
      description: product?.description || '',
      price: product?.price || 0,
      category: product?.category || '',
      stock: product?.stock || 1,
      tags: product?.tags || []
    }
  })

  const watchedCategory = watch('category')

  const categories = ['Makanan', 'Minuman', 'Kerajinan', 'Fashion', 'Elektronik', 'Lainnya']

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      const updatedTags = [...tags, newTag.trim()]
      setTags(updatedTags)
      setValue('tags', updatedTags)
      setNewTag('')
    }
  }

  const handleRemoveTag = (tagToRemove: string) => {
    const updatedTags = tags.filter(tag => tag !== tagToRemove)
    setTags(updatedTags)
    setValue('tags', updatedTags)
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const onSubmit = async (data: ProductFormData) => {
    if (!user) {
      setError('Silakan login terlebih dahulu')
      return
    }

    setIsLoading(true)
    setError('')
    setSuccess('')

    try {
      const productData = {
        ...data,
        tags,
        image: imagePreview || `https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/95c4d0c0-4091-4f7d-8156-807cdeff2a7c.jpg`,
        seller: user.businessName || user.name,
        sellerId: user.id,
        rating: product?.rating || 0,
        reviews: product?.reviews || []
      }

      if (product) {
        await updateProduct(product.id, productData)
        setSuccess('Produk berhasil diperbarui')
      } else {
        await addProduct(productData)
        setSuccess('Produk berhasil ditambahkan')
      }

      setTimeout(() => {
        onSuccess?.()
      }, 1000)
    } catch (err) {
      setError('Terjadi kesalahan, silakan coba lagi')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-500/20 border-green-500/50">
          <AlertDescription className="text-green-100">{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        {/* Left Column */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-white">Nama Produk</Label>
            <Input
              id="name"
              {...register('name')}
              className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
              placeholder="Masukkan nama produk"
            />
            {errors.name && (
              <p className="text-sm text-red-400">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="text-white">Kategori</Label>
            <Select onValueChange={(value) => setValue('category', value)} defaultValue={watchedCategory}>
              <SelectTrigger className="bg-white/20 border-white/30 text-white">
                <SelectValue placeholder="Pilih kategori" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.category && (
              <p className="text-sm text-red-400">{errors.category.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price" className="text-white">Harga (Rp)</Label>
              <Input
                id="price"
                type="number"
                {...register('price', { valueAsNumber: true })}
                className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                placeholder="0"
              />
              {errors.price && (
                <p className="text-sm text-red-400">{errors.price.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="stock" className="text-white">Stok</Label>
              <Input
                id="stock"
                type="number"
                {...register('stock', { valueAsNumber: true })}
                className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                placeholder="0"
              />
              {errors.stock && (
                <p className="text-sm text-red-400">{errors.stock.message}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-white">Tags</Label>
            <div className="flex gap-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                placeholder="Tambah tag"
              />
              <Button type="button" onClick={handleAddTag} size="sm" className="bg-white text-purple-600 hover:bg-purple-50">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="bg-purple-500 text-white">
                  {tag}
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="ml-2 hover:text-red-200"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="description" className="text-white">Deskripsi Produk</Label>
            <Textarea
              id="description"
              {...register('description')}
              className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30 min-h-[120px]"
              placeholder="Deskripsikan produk Anda..."
            />
            {errors.description && (
              <p className="text-sm text-red-400">{errors.description.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label className="text-white">Gambar Produk</Label>
            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-center w-full">
                  {imagePreview ? (
                    <div className="relative">
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setImagePreview('')}
                        className="absolute top-2 right-2 bg-red-500 text-white hover:bg-red-600"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-white/30 rounded-lg cursor-pointer hover:bg-white/10">
                      <Upload className="w-8 h-8 text-purple-200 mb-2" />
                      <span className="text-sm text-purple-200">Klik untuk upload gambar</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <div className="flex gap-4 pt-4">
        <Button type="submit" className="bg-white text-purple-600 hover:bg-purple-50" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {product ? 'Memperbarui...' : 'Menambahkan...'}
            </>
          ) : (
            product ? 'Perbarui Produk' : 'Tambah Produk'
          )}
        </Button>
        <Button type="button" variant="outline" onClick={onSuccess} className="bg-transparent border-white text-white hover:bg-white/20">
          Batal
        </Button>
      </div>
    </form>
  )
}
