/**
 * Logo component for UMKM Tangerang Gemilang
 * Displays the brand logo with text
 */

export default function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
        <span className="text-purple-600 font-bold text-lg">U</span>
      </div>
      <span className="text-white font-bold text-lg hidden sm:block">
        UMKM Tangerang
      </span>
    </div>
  )
}
