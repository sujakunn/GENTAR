/**
 * Orders page for viewing and managing customer orders
 * Displays order history, status tracking, and order management
 */

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, Search, Filter, Package, Truck, CheckCircle, Clock, XCircle, Eye, Download, CreditCard } from 'lucide-react'
import { Link } from 'react-router'
import { useAuthStore } from '@/store/authStore'

export default function OrdersPage() {
  const { user } = useAuthStore()
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  // Mock orders data
  const orders = [
    {
      id: 'ORD-001',
      date: '2024-01-15',
      customer: 'Ahmad Fauzi',
      items: [
        { name: 'Keripik Pisang Premium', quantity: 2, price: 25000 },
        { name: 'Madu Hutan Murni', quantity: 1, price: 85000 }
      ],
      total: 135000,
      status: 'completed',
      paymentMethod: 'Transfer Bank',
      shippingAddress: 'Jl. Contoh No. 123, Tangerang'
    },
    {
      id: 'ORD-002',
      date: '2024-01-14',
      customer: 'Siti Nurhaliza',
      items: [
        { name: 'Tas Anyaman Bambu', quantity: 1, price: 120000 }
      ],
      total: 120000,
      status: 'shipped',
      paymentMethod: 'E-Wallet',
      shippingAddress: 'Jl. Example No. 456, Tangerang'
    },
    {
      id: 'ORD-003',
      date: '2024-01-13',
      customer: 'Budi Santoso',
      items: [
        { name: 'Batik Tangerang', quantity: 1, price: 150000 },
        { name: 'Kue Lumpur Tradisional', quantity: 2, price: 35000 }
      ],
      total: 220000,
      status: 'processing',
      paymentMethod: 'COD',
      shippingAddress: 'Jl. Sample No. 789, Tangerang'
    },
    {
      id: 'ORD-004',
      date: '2024-01-12',
      customer: 'Dewi Lestari',
      items: [
        { name: 'Lampu Hias Bamboo', quantity: 1, price: 95000 }
      ],
      total: 95000,
      status: 'cancelled',
      paymentMethod: 'Transfer Bank',
      shippingAddress: 'Jl. Test No. 101, Tangerang'
    }
  ]

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.customer.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />
      case 'shipped': return <Truck className="w-4 h-4" />
      case 'processing': return <Clock className="w-4 h-4" />
      case 'cancelled': return <XCircle className="w-4 h-4" />
      default: return <Package className="w-4 h-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500'
      case 'shipped': return 'bg-blue-500'
      case 'processing': return 'bg-yellow-500'
      case 'cancelled': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Selesai'
      case 'shipped': return 'Dikirim'
      case 'processing': return 'Diproses'
      case 'cancelled': return 'Dibatalkan'
      default: return 'Pending'
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <Package className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Silakan Masuk</h2>
          <p className="text-purple-100 mb-6">Anda perlu masuk untuk melihat pesanan</p>
          <Link to="/auth">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Masuk Sekarang
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-white">
              {user.role === 'seller' ? 'Kelola Pesanan' : 'Pesanan Saya'}
            </h1>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-5 h-5" />
            <Input
              placeholder="Cari pesanan..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="bg-white/20 border-white/30 text-white">
              <SelectValue placeholder="Filter Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Status</SelectItem>
              <SelectItem value="processing">Diproses</SelectItem>
              <SelectItem value="shipped">Dikirim</SelectItem>
              <SelectItem value="completed">Selesai</SelectItem>
              <SelectItem value="cancelled">Dibatalkan</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Orders Tabs */}
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="bg-white/10 border-white/20">
            <TabsTrigger value="all" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Semua ({filteredOrders.length})
            </TabsTrigger>
            <TabsTrigger value="processing" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Diproses ({filteredOrders.filter(o => o.status === 'processing').length})
            </TabsTrigger>
            <TabsTrigger value="shipped" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Dikirim ({filteredOrders.filter(o => o.status === 'shipped').length})
            </TabsTrigger>
            <TabsTrigger value="completed" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Selesai ({filteredOrders.filter(o => o.status === 'completed').length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <div className="space-y-4">
              {filteredOrders.map((order) => (
                <Card key={order.id} className="bg-white/10 backdrop-blur-sm border-white/20">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-white">{order.id}</CardTitle>
                        <CardDescription className="text-purple-200">
                          {order.date} • {order.customer}
                        </CardDescription>
                      </div>
                      <Badge className={`flex items-center gap-1 ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {getStatusText(order.status)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Order Items */}
                      <div className="space-y-2">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <div>
                              <span className="text-white">{item.name}</span>
                              <span className="text-purple-200 ml-2">x{item.quantity}</span>
                            </div>
                            <span className="text-white">Rp {(item.price * item.quantity).toLocaleString('id-ID')}</span>
                          </div>
                        ))}
                      </div>

                      <div className="border-t border-white/20 pt-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-purple-200">Subtotal</span>
                          <span className="text-white">Rp {order.total.toLocaleString('id-ID')}</span>
                        </div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-purple-200">Ongkos Kirim</span>
                          <span className="text-white">Rp 15.000</span>
                        </div>
                        <div className="flex justify-between items-center font-semibold">
                          <span className="text-white">Total</span>
                          <span className="text-white">Rp {(order.total + 15000).toLocaleString('id-ID')}</span>
                        </div>
                      </div>

                      <div className="flex justify-between items-center pt-4 border-t border-white/20">
                        <div className="text-sm text-purple-200">
                          <p>Pembayaran: {order.paymentMethod}</p>
                          <p>Kirim ke: {order.shippingAddress}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="bg-transparent border-white text-white hover:bg-white/20">
                            <Eye className="w-4 h-4 mr-1" />
                            Detail
                          </Button>
                          {order.status === 'completed' && (
                            <Button variant="outline" size="sm" className="bg-transparent border-white text-white hover:bg-white/20">
                              <Download className="w-4 h-4 mr-1" />
                              Invoice
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {filteredOrders.length === 0 && (
                <div className="text-center py-12">
                  <Package className="w-16 h-16 text-purple-200 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Tidak ada pesanan</h3>
                  <p className="text-purple-100">Tidak ada pesanan yang cocok dengan filter Anda</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="processing">
            <div className="space-y-4">
              {filteredOrders.filter(o => o.status === 'processing').map((order) => (
                <Card key={order.id} className="bg-white/10 backdrop-blur-sm border-white/20">
                  {/* Same content as above */}
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-white">{order.id}</CardTitle>
                        <CardDescription className="text-purple-200">
                          {order.date} • {order.customer}
                        </CardDescription>
                      </div>
                      <Badge className={`flex items-center gap-1 ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {getStatusText(order.status)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <div>
                              <span className="text-white">{item.name}</span>
                              <span className="text-purple-200 ml-2">x{item.quantity}</span>
                            </div>
                            <span className="text-white">Rp {(item.price * item.quantity).toLocaleString('id-ID')}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-between items-center pt-4 border-t border-white/20">
                        <div className="text-sm text-purple-200">
                          <p>Total: Rp {(order.total + 15000).toLocaleString('id-ID')}</p>
                        </div>
                        <Button className="bg-white text-purple-600 hover:bg-purple-50">
                          Proses Pesanan
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="shipped">
            <div className="space-y-4">
              {filteredOrders.filter(o => o.status === 'shipped').map((order) => (
                <Card key={order.id} className="bg-white/10 backdrop-blur-sm border-white/20">
                  {/* Similar content structure */}
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-white">{order.id}</CardTitle>
                        <CardDescription className="text-purple-200">
                          {order.date} • {order.customer}
                        </CardDescription>
                      </div>
                      <Badge className={`flex items-center gap-1 ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {getStatusText(order.status)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <div>
                              <span className="text-white">{item.name}</span>
                              <span className="text-purple-200 ml-2">x{item.quantity}</span>
                            </div>
                            <span className="text-white">Rp {(item.price * item.quantity).toLocaleString('id-ID')}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-between items-center pt-4 border-t border-white/20">
                        <div className="text-sm text-purple-200">
                          <p>Total: Rp {(order.total + 15000).toLocaleString('id-ID')}</p>
                        </div>
                        <Button className="bg-white text-purple-600 hover:bg-purple-50">
                          Update Status
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed">
            <div className="space-y-4">
              {filteredOrders.filter(o => o.status === 'completed').map((order) => (
                <Card key={order.id} className="bg-white/10 backdrop-blur-sm border-white/20">
                  {/* Similar content structure */}
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-white">{order.id}</CardTitle>
                        <CardDescription className="text-purple-200">
                          {order.date} • {order.customer}
                        </CardDescription>
                      </div>
                      <Badge className={`flex items-center gap-1 ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {getStatusText(order.status)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <div>
                              <span className="text-white">{item.name}</span>
                              <span className="text-purple-200 ml-2">x{item.quantity}</span>
                            </div>
                            <span className="text-white">Rp {(item.price * item.quantity).toLocaleString('id-ID')}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-between items-center pt-4 border-t border-white/20">
                        <div className="text-sm text-purple-200">
                          <p>Total: Rp {(order.total + 15000).toLocaleString('id-ID')}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="bg-transparent border-white text-white hover:bg-white/20">
                            <Download className="w-4 h-4 mr-1" />
                            Invoice
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}