/**
 * Professional checkout page with payment integration
 * Features multi-step checkout, payment methods, and order summary
 */

import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  ArrowLeft, 
  ShoppingCart, 
  MapPin, 
  CreditCard, 
  Truck, 
  CheckCircle, 
  Clock,
  Shield,
  Loader2,
  Bank,
  Smartphone,
  CreditCard as CardIcon,
  Package,
  QrCode,
  Copy,
  Download
} from 'lucide-react'
import { Link } from 'react-router'
import { useCartStore } from '@/store/cartStore'
import { useAuthStore } from '@/store/authStore'
import { useOrderStore, ShippingAddress } from '@/store/orderStore'
import { usePaymentStore, PaymentMethod } from '@/store/paymentStore'

type CheckoutStep = 'cart' | 'shipping' | 'payment' | 'confirmation'

export default function CheckoutPage() {
  const navigate = useNavigate()
  const { items, totalPrice, clearCart } = useCartStore()
  const { user, isAuthenticated } = useAuthStore()
  const { createOrder, isLoading: orderLoading } = useOrderStore()
  const { 
    paymentMethods, 
    initializePayment, 
    currentTransaction, 
    isLoading: paymentLoading 
  } = usePaymentStore()

  const [currentStep, setCurrentStep] = useState<CheckoutStep>('cart')
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>({
    name: user?.name || '',
    phone: user?.phone || '',
    address: user?.address || '',
    city: '',
    province: '',
    postalCode: '',
    notes: ''
  })
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('')
  const [orderNotes, setOrderNotes] = useState('')
  const [error, setError] = useState('')

  // Payment methods data - langsung didefinisikan untuk memastikan selalu muncul
  const paymentMethodsData = [
    {
      id: 'bca_va',
      name: 'BCA Virtual Account',
      type: 'bank_transfer',
      icon: '🏦',
      enabled: true,
      fee: 5000
    },
    {
      id: 'mandiri_va',
      name: 'Mandiri Virtual Account',
      type: 'bank_transfer',
      icon: '🏦',
      enabled: true,
      fee: 5000
    },
    {
      id: 'bri_va',
      name: 'BRI Virtual Account',
      type: 'bank_transfer',
      icon: '🏦',
      enabled: true,
      fee: 5000
    },
    {
      id: 'gopay',
      name: 'GoPay',
      type: 'e_wallet',
      icon: '📱',
      enabled: true,
      fee: 2000
    },
    {
      id: 'ovo',
      name: 'OVO',
      type: 'e_wallet',
      icon: '📱',
      enabled: true,
      fee: 2000
    },
    {
      id: 'dana',
      name: 'DANA',
      type: 'e_wallet',
      icon: '📱',
      enabled: true,
      fee: 2000
    },
    {
      id: 'credit_card',
      name: 'Kartu Kredit',
      type: 'credit_card',
      icon: '💳',
      enabled: true,
      fee: 10000
    },
    {
      id: 'cod',
      name: 'COD (Bayar di Tempat)',
      type: 'cod',
      icon: '📦',
      enabled: true,
      fee: 0
    }
  ]

  const steps = [
    { id: 'cart', name: 'Keranjang', icon: ShoppingCart },
    { id: 'shipping', name: 'Pengiriman', icon: MapPin },
    { id: 'payment', name: 'Pembayaran', icon: CreditCard },
    { id: 'confirmation', name: 'Konfirmasi', icon: CheckCircle }
  ]

  const getStepIndex = (step: CheckoutStep) => steps.findIndex(s => s.id === step)
  const currentStepIndex = getStepIndex(currentStep)

  const shippingCost = 15000
  const serviceFee = 2000
  const totalAmount = totalPrice + shippingCost + serviceFee

  // Get selected payment info
  const selectedPayment = paymentMethodsData.find(m => m.id === selectedPaymentMethod)
  const paymentFee = selectedPayment?.fee || 0
  const finalTotal = totalAmount + paymentFee

  // Debug log
  useEffect(() => {
    console.log('CheckoutPage mounted')
    console.log('Payment methods available:', paymentMethodsData.length)
    console.log('Current step:', currentStep)
    console.log('Items in cart:', items.length)
    console.log('User authenticated:', isAuthenticated)
    
    // Auto-navigate to shipping step if coming from cart
    if (currentStep === 'cart' && items.length > 0) {
      console.log('Auto-navigating to shipping step')
      setTimeout(() => {
        setCurrentStep('shipping')
      }, 500)
    }
  }, [currentStep, items.length, isAuthenticated])

  const getPaymentIcon = (type: string) => {
    switch (type) {
      case 'bank_transfer': return <Bank className="w-5 h-5" />
      case 'e_wallet': return <Smartphone className="w-5 h-5" />
      case 'credit_card': return <CardIcon className="w-5 h-5" />
      case 'cod': return <Package className="w-5 h-5" />
      default: return <CreditCard className="w-5 h-5" />
    }
  }

  const handleNextStep = () => {
    console.log('handleNextStep called, current step:', currentStep)
    
    if (currentStep === 'cart' && items.length === 0) {
      setError('Keranjang belanja kosong')
      return
    }
    
    if (currentStep === 'shipping') {
      if (!shippingAddress.name || !shippingAddress.phone || !shippingAddress.address) {
        setError('Silakan lengkapi alamat pengiriman')
        return
      }
    }
    
    if (currentStep === 'payment' && !selectedPaymentMethod) {
      setError('Silakan pilih metode pembayaran')
      return
    }
    
    setError('')
    
    if (currentStep === 'payment') {
      handlePlaceOrder()
    } else {
      const nextStep = steps[currentStepIndex + 1]?.id as CheckoutStep
      if (nextStep) {
        console.log('Moving to next step:', nextStep)
        setCurrentStep(nextStep)
      }
    }
  }

  const handlePlaceOrder = async () => {
    if (!isAuthenticated) {
      navigate('/auth')
      return
    }

    try {
      setError('')
      console.log('Starting checkout process...')
      console.log('Selected Payment Method:', selectedPaymentMethod)
      console.log('Final Total:', finalTotal)
      
      // Validate shipping address
      if (!shippingAddress.name || !shippingAddress.phone || !shippingAddress.address || !shippingAddress.city) {
        setError('Silakan lengkapi alamat pengiriman')
        return
      }
      
      // Validate payment method
      if (!selectedPaymentMethod) {
        setError('Silakan pilih metode pembayaran')
        return
      }
      
      console.log('Creating order...')
      // Create order
      const order = await createOrder(shippingAddress, selectedPaymentMethod, orderNotes)
      console.log('Order created:', order)
      
      console.log('Initializing payment...')
      // Initialize payment
      const transaction = await initializePayment(order.id, finalTotal, selectedPaymentMethod)
      console.log('Payment initialized:', transaction)
      
      // Show success message
      showNotification('Pesanan berhasil dibuat! Silakan lanjutkan pembayaran.', 'success')
      
      // Redirect to payment status page
      setTimeout(() => {
        navigate(`/payment/${transaction.id}`)
        setCurrentStep('confirmation')
      }, 1500)
    } catch (err) {
      console.error('Checkout error:', err)
      setError('Gagal membuat pesanan. Silakan coba lagi.')
    }
  }

  const handleCopyVA = (vaNumber: string) => {
    navigator.clipboard.writeText(vaNumber)
    showNotification('Nomor VA berhasil disalin!', 'success')
  }

  const handleDownloadQR = () => {
    // Generate QR code for payment
    if (currentTransaction) {
      const qrData = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentTransaction.transactionId + '|' + currentTransaction.amount)}`
      
      // Create download link
      const link = document.createElement('a')
      link.href = qrData
      link.download = `QR-Payment-${currentTransaction.transactionId}.png`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      
      showNotification('QR Code berhasil diunduh!', 'success')
    }
  }

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    const notification = document.createElement('div')
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300 ${
      type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
    }`
    notification.innerHTML = `
      <div class="flex items-center gap-2">
        ${type === 'success' ? 
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>' :
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>'
        }
        <span>${message}</span>
      </div>
    `
    document.body.appendChild(notification)
    
    // Animate in
    setTimeout(() => {
      notification.classList.remove('translate-x-full')
    }, 100)
    
    // Remove after 3 seconds
    setTimeout(() => {
      notification.classList.add('translate-x-full')
      setTimeout(() => {
        if (document.body.contains(notification)) {
          document.body.removeChild(notification)
        }
      }, 300)
    }, 3000)
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <ShoppingCart className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Silakan Masuk</h2>
          <p className="text-purple-100 mb-6">Anda perlu masuk untuk melakukan checkout</p>
          <Link to="/auth">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Masuk Sekarang
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <ShoppingCart className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Keranjang Kosong</h2>
          <p className="text-purple-100 mb-6">Belum ada produk di keranjang Anda</p>
          <Link to="/marketplace">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Mulai Belanja
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link to="/cart">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-white">Checkout</h1>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                  index <= currentStepIndex
                    ? 'bg-white text-purple-600 border-white'
                    : 'border-white/30 text-white/50'
                }`}>
                  <step.icon className="w-5 h-5" />
                </div>
                <span className={`ml-3 text-sm font-medium ${
                  index <= currentStepIndex ? 'text-white' : 'text-white/50'
                }`}>
                  {step.name}
                </span>
                {index < steps.length - 1 && (
                  <div className={`w-16 h-0.5 mx-4 ${
                    index < currentStepIndex ? 'bg-white' : 'bg-white/30'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {error && (
              <Alert variant="destructive" className="mb-6">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Step 1: Cart Review */}
            {currentStep === 'cart' && (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Ringkasan Pesanan</CardTitle>
                  <CardDescription className="text-purple-200">
                    Periksa kembali produk yang Anda beli
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {items.map((item) => (
                      <div key={item.id} className="flex items-center gap-4 p-4 bg-white/5 rounded-lg">
                        <img 
                          src={item.image} 
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-white">{item.name}</h3>
                          <p className="text-sm text-purple-200">oleh {item.seller}</p>
                          <Badge variant="secondary" className="mt-1 bg-purple-500 text-white">
                            {item.category}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-white">
                            Rp {(item.price * item.quantity).toLocaleString('id-ID')}
                          </div>
                          <div className="text-sm text-purple-200">
                            Rp {item.price.toLocaleString('id-ID')} x {item.quantity}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 2: Shipping Address */}
            {currentStep === 'shipping' && (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Alamat Pengiriman</CardTitle>
                  <CardDescription className="text-purple-200">
                    Masukkan alamat pengiriman untuk pesanan Anda
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-white">Nama Lengkap</Label>
                      <Input
                        id="name"
                        value={shippingAddress.name}
                        onChange={(e) => setShippingAddress({...shippingAddress, name: e.target.value})}
                        className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-white">Nomor Telepon</Label>
                      <Input
                        id="phone"
                        value={shippingAddress.phone}
                        onChange={(e) => setShippingAddress({...shippingAddress, phone: e.target.value})}
                        className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                        placeholder="081234567890"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="address" className="text-white">Alamat Lengkap</Label>
                    <Textarea
                      id="address"
                      value={shippingAddress.address}
                      onChange={(e) => setShippingAddress({...shippingAddress, address: e.target.value})}
                      className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30 min-h-[100px]"
                      placeholder="Jl. Contoh No. 123, RT/RW 001/002"
                    />
                  </div>
                  
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city" className="text-white">Kota</Label>
                      <Input
                        id="city"
                        value={shippingAddress.city}
                        onChange={(e) => setShippingAddress({...shippingAddress, city: e.target.value})}
                        className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                        placeholder="Tangerang"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="province" className="text-white">Provinsi</Label>
                      <Input
                        id="province"
                        value={shippingAddress.province}
                        onChange={(e) => setShippingAddress({...shippingAddress, province: e.target.value})}
                        className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                        placeholder="Banten"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="postalCode" className="text-white">Kode Pos</Label>
                      <Input
                        id="postalCode"
                        value={shippingAddress.postalCode}
                        onChange={(e) => setShippingAddress({...shippingAddress, postalCode: e.target.value})}
                        className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                        placeholder="15111"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="notes" className="text-white">Catatan (Opsional)</Label>
                    <Textarea
                      id="notes"
                      value={shippingAddress.notes}
                      onChange={(e) => setShippingAddress({...shippingAddress, notes: e.target.value})}
                      className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                      placeholder="Catatan untuk kurir..."
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 3: Payment Method */}
            {currentStep === 'payment' && (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Metode Pembayaran</CardTitle>
                  <CardDescription className="text-purple-200">
                    Pilih metode pembayaran yang Anda inginkan
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Debug Info */}
                  <div className="mb-4 p-3 bg-purple-900/30 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-purple-200">Payment Methods Debug:</span>
                      <span className="text-sm text-purple-200">Count: {paymentMethodsData.length}</span>
                    </div>
                    <div className="text-xs text-purple-300">
                      Selected: {selectedPaymentMethod || 'None'}
                    </div>
                    <div className="text-xs text-purple-300">
                      Step: {currentStep}
                    </div>
                    <div className="text-xs text-purple-300">
                      Available Methods: {paymentMethodsData.map(m => m.id).join(', ')}
                    </div>
                  </div>

                  <Tabs defaultValue="all" className="w-full">
                    <TabsList className="grid w-full grid-cols-5 bg-white/10">
                      <TabsTrigger value="all" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">Semua</TabsTrigger>
                      <TabsTrigger value="bank" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">Bank</TabsTrigger>
                      <TabsTrigger value="ewallet" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">E-Wallet</TabsTrigger>
                      <TabsTrigger value="card" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">Kartu</TabsTrigger>
                      <TabsTrigger value="cod" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">COD</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="all" className="space-y-4 mt-4">
                      {paymentMethodsData
                        .filter(method => method.enabled)
                        .map((method) => (
                          <div
                            key={method.id}
                            className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                              selectedPaymentMethod === method.id
                                ? 'border-white bg-white/20'
                                : 'border-white/30 hover:border-white/50'
                            }`}
                            onClick={() => setSelectedPaymentMethod(method.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                                  {getPaymentIcon(method.type)}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-white">{method.name}</h3>
                                  {method.fee > 0 && (
                                    <p className="text-sm text-purple-200">
                                      Biaya admin: Rp {method.fee.toLocaleString('id-ID')}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className={`w-5 h-5 rounded-full border-2 ${
                                selectedPaymentMethod === method.id
                                  ? 'border-white bg-white'
                                  : 'border-white/50'
                              }`}>
                                {selectedPaymentMethod === method.id && (
                                  <div className="w-3 h-3 bg-purple-600 rounded-full m-0.5" />
                                )}
                              </div>
                            </div>
                          </div>
                        ))
                      }
                    </TabsContent>
                    
                    <TabsContent value="bank" className="space-y-4 mt-4">
                      {paymentMethodsData
                        .filter(method => method.enabled && method.type === 'bank_transfer')
                        .map((method) => (
                          <div
                            key={method.id}
                            className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                              selectedPaymentMethod === method.id
                                ? 'border-white bg-white/20'
                                : 'border-white/30 hover:border-white/50'
                            }`}
                            onClick={() => setSelectedPaymentMethod(method.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                                  {getPaymentIcon(method.type)}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-white">{method.name}</h3>
                                  {method.fee > 0 && (
                                    <p className="text-sm text-purple-200">
                                      Biaya admin: Rp {method.fee.toLocaleString('id-ID')}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className={`w-5 h-5 rounded-full border-2 ${
                                selectedPaymentMethod === method.id
                                  ? 'border-white bg-white'
                                  : 'border-white/50'
                              }`}>
                                {selectedPaymentMethod === method.id && (
                                  <div className="w-3 h-3 bg-purple-600 rounded-full m-0.5" />
                                )}
                              </div>
                            </div>
                          </div>
                        ))
                      }
                    </TabsContent>
                    
                    <TabsContent value="ewallet" className="space-y-4 mt-4">
                      {paymentMethodsData
                        .filter(method => method.enabled && method.type === 'e_wallet')
                        .map((method) => (
                          <div
                            key={method.id}
                            className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                              selectedPaymentMethod === method.id
                                ? 'border-white bg-white/20'
                                : 'border-white/30 hover:border-white/50'
                            }`}
                            onClick={() => setSelectedPaymentMethod(method.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                                  {getPaymentIcon(method.type)}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-white">{method.name}</h3>
                                  {method.fee > 0 && (
                                    <p className="text-sm text-purple-200">
                                      Biaya admin: Rp {method.fee.toLocaleString('id-ID')}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className={`w-5 h-5 rounded-full border-2 ${
                                selectedPaymentMethod === method.id
                                  ? 'border-white bg-white'
                                  : 'border-white/50'
                              }`}>
                                {selectedPaymentMethod === method.id && (
                                  <div className="w-3 h-3 bg-purple-600 rounded-full m-0.5" />
                                )}
                              </div>
                            </div>
                          </div>
                        ))
                      }
                    </TabsContent>
                    
                    <TabsContent value="card" className="space-y-4 mt-4">
                      {paymentMethodsData
                        .filter(method => method.enabled && method.type === 'credit_card')
                        .map((method) => (
                          <div
                            key={method.id}
                            className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                              selectedPaymentMethod === method.id
                                ? 'border-white bg-white/20'
                                : 'border-white/30 hover:border-white/50'
                            }`}
                            onClick={() => setSelectedPaymentMethod(method.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                                  {getPaymentIcon(method.type)}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-white">{method.name}</h3>
                                  {method.fee > 0 && (
                                    <p className="text-sm text-purple-200">
                                      Biaya admin: Rp {method.fee.toLocaleString('id-ID')}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className={`w-5 h-5 rounded-full border-2 ${
                                selectedPaymentMethod === method.id
                                  ? 'border-white bg-white'
                                  : 'border-white/50'
                              }`}>
                                {selectedPaymentMethod === method.id && (
                                  <div className="w-3 h-3 bg-purple-600 rounded-full m-0.5" />
                                )}
                              </div>
                            </div>
                          </div>
                        ))
                      }
                    </TabsContent>
                    
                    <TabsContent value="cod" className="space-y-4 mt-4">
                      {paymentMethodsData
                        .filter(method => method.enabled && method.type === 'cod')
                        .map((method) => (
                          <div
                            key={method.id}
                            className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                              selectedPaymentMethod === method.id
                                ? 'border-white bg-white/20'
                                : 'border-white/30 hover:border-white/50'
                            }`}
                            onClick={() => setSelectedPaymentMethod(method.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                                  {getPaymentIcon(method.type)}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-white">{method.name}</h3>
                                  {method.fee > 0 && (
                                    <p className="text-sm text-purple-200">
                                      Biaya admin: Rp {method.fee.toLocaleString('id-ID')}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className={`w-5 h-5 rounded-full border-2 ${
                                selectedPaymentMethod === method.id
                                  ? 'border-white bg-white'
                                  : 'border-white/50'
                              }`}>
                                {selectedPaymentMethod === method.id && (
                                  <div className="w-3 h-3 bg-purple-600 rounded-full m-0.5" />
                                )}
                              </div>
                            </div>
                          </div>
                        ))
                      }
                    </TabsContent>
                  </Tabs>
                  
                  <div className="mt-6 space-y-2">
                    <Label htmlFor="orderNotes" className="text-white">Catatan Pesanan (Opsional)</Label>
                    <Textarea
                      id="orderNotes"
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      className="bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                      placeholder="Catatan untuk penjual..."
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 4: Confirmation */}
            {currentStep === 'confirmation' && currentTransaction && (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    Pesanan Berhasil Dibuat
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    Silakan lakukan pembayaran untuk menyelesaikan pesanan Anda
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-green-500/20 border border-green-500/50 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-white">ID Pesanan</h3>
                        <p className="text-2xl font-bold text-white">{currentTransaction.orderId}</p>
                      </div>
                      <Badge className="bg-green-500 text-white">
                        Menunggu Pembayaran
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="bg-white/10 rounded-lg p-4">
                    <h3 className="font-semibold text-white mb-3">Detail Pembayaran</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-purple-200">Metode Pembayaran</span>
                        <span className="text-white">
                          {paymentMethodsData.find(m => m.id === selectedPaymentMethod)?.name}
                        </span>
                      </div>
                      {currentTransaction.vaNumber && (
                        <div className="flex justify-between items-center">
                          <span className="text-purple-200">Nomor Virtual Account</span>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-white">{currentTransaction.vaNumber}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleCopyVA(currentTransaction.vaNumber)}
                              className="text-white hover:bg-white/20"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-purple-200">Total Pembayaran</span>
                        <span className="font-bold text-white">
                          Rp {currentTransaction.amount.toLocaleString('id-ID')}
                        </span>
                      </div>
                      {currentTransaction.expiryDate && (
                        <div className="flex justify-between">
                          <span className="text-purple-200">Batas Pembayaran</span>
                          <span className="text-white">
                            {new Date(currentTransaction.expiryDate).toLocaleString('id-ID')}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Payment Actions */}
                  <div className="space-y-3">
                    {currentTransaction && currentTransaction.paymentUrl && (
                      <Button 
                        className="w-full bg-white text-purple-600 hover:bg-purple-50"
                        onClick={() => window.open(currentTransaction.paymentUrl, '_blank')}
                      >
                        Bayar Sekarang
                      </Button>
                    )}
                    
                    {currentTransaction && currentTransaction.vaNumber && (
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          className="flex-1 bg-transparent border-white text-white hover:bg-white/20"
                          onClick={() => handleCopyVA(currentTransaction.vaNumber)}
                        >
                          <Copy className="w-4 h-4 mr-2" />
                          Salin VA
                        </Button>
                        <Button 
                          variant="outline" 
                          className="flex-1 bg-transparent border-white text-white hover:bg-white/20"
                          onClick={handleDownloadQR}
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download QR
                        </Button>
                      </div>
                    )}
                    
                    {selectedPaymentMethod === 'credit_card' && currentTransaction && (
                      <Button 
                        className="w-full bg-white text-purple-600 hover:bg-purple-50"
                        onClick={() => {
                          // Simulate credit card payment
                          showNotification('Mengarahkan ke halaman pembayaran kartu kredit...', 'success')
                          setTimeout(() => {
                            window.open(currentTransaction.paymentUrl, '_blank')
                          }, 1000)
                        }}
                      >
                        Bayar dengan Kartu Kredit
                      </Button>
                    )}
                    
                    {selectedPaymentMethod === 'cod' && (
                      <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Package className="w-5 h-5 text-yellow-400" />
                          <span className="font-semibold text-white">Pembayaran di Tempat (COD)</span>
                        </div>
                        <p className="text-sm text-yellow-100">
                          Silakan siapkan uang pas saat kurir mengantarkan pesanan Anda. Pesanan akan diproses setelah checkout selesai.
                        </p>
                      </div>
                    )}
                    
                    <div className="text-center">
                      <Button 
                        variant="outline" 
                        className="bg-transparent border-white text-white hover:bg-white/20"
                        onClick={() => navigate('/orders')}
                      >
                        Lihat Status Pesanan
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-6">
              <Button
                variant="outline"
                onClick={() => {
                  const prevStep = steps[currentStepIndex - 1]?.id as CheckoutStep
                  if (prevStep) setCurrentStep(prevStep)
                }}
                disabled={currentStepIndex === 0}
                className="bg-transparent border-white text-white hover:bg-white/20"
              >
                Kembali
              </Button>
              
              <Button
                onClick={handleNextStep}
                disabled={orderLoading || paymentLoading}
                className="bg-white text-purple-600 hover:bg-purple-50"
              >
                {orderLoading || paymentLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Memproses...
                  </>
                ) : currentStep === 'confirmation' ? 'Selesai' : 'Lanjutkan'}
              </Button>
            </div>
          </div>

          {/* Order Summary Sidebar */}
          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Ringkasan Pesanan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="text-purple-200">
                        {item.name} x {item.quantity}
                      </span>
                      <span className="text-white">
                        Rp {(item.price * item.quantity).toLocaleString('id-ID')}
                      </span>
                    </div>
                  ))}
                </div>
                
                <Separator className="bg-white/20" />
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-purple-200">Subtotal</span>
                    <span className="text-white">Rp {totalPrice.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-200">Ongkos Kirim</span>
                    <span className="text-white">Rp {shippingCost.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-200">Biaya Layanan</span>
                    <span className="text-white">Rp {serviceFee.toLocaleString('id-ID')}</span>
                  </div>
                  {selectedPayment && paymentFee > 0 && (
                    <div className="flex justify-between">
                      <span className="text-purple-200">Biaya Admin ({selectedPayment.name})</span>
                      <span className="text-white">Rp {paymentFee.toLocaleString('id-ID')}</span>
                    </div>
                  )}
                </div>
                
                <Separator className="bg-white/20" />
                
                <div className="flex justify-between text-lg font-semibold">
                  <span className="text-white">Total</span>
                  <span className="text-white">Rp {finalTotal.toLocaleString('id-ID')}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Keamanan Pembayaran
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-purple-200">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Pembayaran aman terenkripsi
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Perlindungan pembeli
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Garansi uang kembali
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
