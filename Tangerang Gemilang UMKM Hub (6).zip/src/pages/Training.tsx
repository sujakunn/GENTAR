/**
 * Enhanced Training page for UMKM Tangerang Gemilang
 * Features training programs, courses, schedules, and registration with modern UI
 */

import { useState } from 'react'
import { useNavigate } from 'react-router'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { 
  Search, 
  Clock, 
  Users, 
  Star, 
  Play, 
  CheckCircle, 
  Calendar,
  MapPin,
  Award,
  BookOpen,
  Target,
  TrendingUp,
  User,
  Video,
  FileText,
  Download,
  Filter
} from 'lucide-react'
import Header from '@/components/layout/Header'

export default function Training() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('upcoming')
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Semua')

  const upcomingTrainings = [
    {
      id: 1,
      title: 'Digital Marketing untuk UMKM',
      instructor: 'Ahmad Fauzi',
      instructorAvatar: '',
      duration: '8 sesi',
      schedule: '15 Oktober - 5 November 2024',
      time: '19:00 - 21:00',
      mode: 'Online',
      price: 250000,
      rating: 4.8,
      participants: 45,
      maxParticipants: 100,
      description: 'Pelajari strategi digital marketing untuk meningkatkan penjualan online dengan praktisi berpengalaman',
      image: 'digital marketing',
      category: 'Marketing',
      level: 'Beginner',
      certificate: true,
      materials: ['Video Tutorial', 'E-Book', 'Case Study', 'Template'],
      highlights: ['SEO & SEM', 'Social Media Marketing', 'Content Strategy', 'Analytics']
    },
    {
      id: 2,
      title: 'Manajemen Keuangan Usaha',
      instructor: 'Siti Nurhaliza',
      instructorAvatar: '',
      duration: '6 sesi',
      schedule: '20 Oktober - 10 November 2024',
      time: '09:00 - 11:00',
      mode: 'Offline',
      price: 300000,
      rating: 4.9,
      participants: 32,
      maxParticipants: 50,
      description: 'Kelola keuangan usaha dengan baik untuk pertumbuhan yang berkelanjutan. Materi praktis langsung applicable!',
      image: 'finance management',
      category: 'Keuangan',
      level: 'Intermediate',
      certificate: true,
      materials: ['Spreadsheet Template', 'Financial Planning Guide', 'Tax Guide'],
      highlights: ['Cash Flow Management', 'Financial Statement', 'Budgeting', 'Investment']
    },
    {
      id: 3,
      title: 'Branding & Packaging Kreatif',
      instructor: 'Budi Santoso',
      instructorAvatar: '',
      duration: '10 sesi',
      schedule: '25 Oktober - 20 November 2024',
      time: '14:00 - 16:00',
      mode: 'Hybrid',
      price: 350000,
      rating: 4.7,
      participants: 28,
      maxParticipants: 40,
      description: 'Ciptakan identitas brand yang kuat dan kemasan yang menarik untuk produk UMKM Anda',
      image: 'branding packaging',
      category: 'Desain',
      level: 'Intermediate',
      certificate: true,
      materials: ['Design Tools', 'Brand Guidelines', 'Packaging Templates'],
      highlights: ['Brand Identity', 'Visual Design', 'Packaging Design', 'Brand Strategy']
    },
    {
      id: 4,
      title: 'E-Commerce Mastery',
      instructor: 'Dewi Lestari',
      instructorAvatar: '',
      duration: '12 sesi',
      schedule: '1 November - 25 November 2024',
      time: '19:00 - 21:00',
      mode: 'Online',
      price: 400000,
      rating: 4.9,
      participants: 38,
      maxParticipants: 60,
      description: 'Master platform e-commerce dan optimasi toko online untuk maksimalkan penjualan',
      image: 'ecommerce mastery',
      category: 'Teknologi',
      level: 'Advanced',
      certificate: true,
      materials: ['Platform Guides', 'Optimization Tools', 'Analytics Dashboard'],
      highlights: ['Shopify', 'Tokopedia', 'Shopee', 'SEO for E-commerce']
    }
  ]

  const completedTrainings = [
    {
      id: 5,
      title: 'Dasar-dasar Kewirausahaan',
      instructor: 'Eko Prasetyo',
      instructorAvatar: '',
      duration: '5 sesi',
      completedDate: '15 September 2024',
      rating: 4.9,
      certificate: true,
      image: 'entrepreneurship basics',
      category: 'Bisnis',
      description: 'Pemahaman fundamental tentang memulai dan mengelola usaha',
      progress: 100,
      score: 95
    },
    {
      id: 6,
      title: 'Customer Service Excellence',
      instructor: 'Rina Susanti',
      instructorAvatar: '',
      duration: '4 sesi',
      completedDate: '10 September 2024',
      rating: 4.8,
      certificate: true,
      image: 'customer service',
      category: 'Layanan',
      description: 'Meningkatkan kualitas pelayanan pelanggan untuk loyalitas jangka panjang',
      progress: 100,
      score: 92
    }
  ]

  const instructors = [
    {
      name: 'Ahmad Fauzi',
      expertise: 'Digital Marketing Specialist',
      experience: '10+ tahun',
      rating: 4.9,
      students: 1250,
      courses: 8,
      avatar: '',
      bio: 'Praktisi digital marketing dengan pengalaman di berbagai perusahaan ternama'
    },
    {
      name: 'Siti Nurhaliza',
      expertise: 'Financial Consultant',
      experience: '15+ tahun',
      rating: 4.9,
      students: 890,
      courses: 6,
      avatar: '',
      bio: 'Konsultan keuangan bersertifikat dengan fokus pada UMKM'
    },
    {
      name: 'Budi Santoso',
      expertise: 'Brand & Design Expert',
      experience: '12+ tahun',
      rating: 4.8,
      students: 756,
      courses: 5,
      avatar: '',
      bio: 'Desainer grafis dan brand strategist dengan portofolio internasional'
    }
  ]

  const categories = ['Semua', 'Marketing', 'Keuangan', 'Desain', 'Teknologi', 'Bisnis', 'Layanan']
  const levels = ['Semua', 'Beginner', 'Intermediate', 'Advanced']

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner': return 'bg-green-500'
      case 'Intermediate': return 'bg-yellow-500'
      case 'Advanced': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'Online': return <Video className="w-4 h-4" />
      case 'Offline': return <MapPin className="w-4 h-4" />
      case 'Hybrid': return <Users className="w-4 h-4" />
      default: return <Calendar className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Kembangkan Kompetensi Usaha Anda
          </h2>
          <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
            Bergabunglah dengan program pelatihan berkualitas untuk meningkatkan kapasitas UMKM Anda bersama para ahli di bidangnya
          </p>
          
          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto mb-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">50+</div>
              <div className="text-purple-100">Program Pelatihan</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">1,200+</div>
              <div className="text-purple-100">Peserta</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">95%</div>
              <div className="text-purple-100">Kepuasan</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-purple-50">
              <BookOpen className="w-5 h-5 mr-2" />
              Jelajahi Pelatihan
            </Button>
            <Button variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white/20">
              <Target className="w-5 h-5 mr-2" />
              Jadi Instruktur
            </Button>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-5 h-5" />
              <Input
                placeholder="Cari pelatihan..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
              />
            </div>
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={`whitespace-nowrap ${
                  selectedCategory === category 
                    ? "bg-white text-purple-600" 
                    : "bg-transparent border-white text-white hover:bg-white/20"
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Tabs */}
      <section className="py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex gap-2 border-b border-white/20">
            <Button
              variant={activeTab === 'upcoming' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('upcoming')}
              className={`${activeTab === 'upcoming' ? 'bg-white text-purple-600' : 'text-white hover:bg-white/20'}`}
            >
              <Calendar className="w-4 h-4 mr-2" />
              Pelatihan Mendatang
            </Button>
            <Button
              variant={activeTab === 'completed' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('completed')}
              className={`${activeTab === 'completed' ? 'bg-white text-purple-600' : 'text-white hover:bg-white/20'}`}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Pelatihan Selesai
            </Button>
            <Button
              variant={activeTab === 'instructors' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('instructors')}
              className={`${activeTab === 'instructors' ? 'bg-white text-purple-600' : 'text-white hover:bg-white/20'}`}
            >
              <User className="w-4 h-4 mr-2" />
              Instruktur
            </Button>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {activeTab === 'upcoming' && (
            <div className="space-y-8">
              <h2 className="text-2xl font-bold text-white">Pelatihan Mendatang</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                {upcomingTrainings.map((training) => (
                  <Card key={training.id} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105 overflow-hidden">
                    <div className="relative">
                      <div className="h-48 bg-gradient-to-r from-purple-500 to-cyan-400 relative">
                        <div className="absolute top-4 right-4 flex gap-2">
                          <Badge className="bg-white text-purple-600">
                            {training.category}
                          </Badge>
                          <Badge className={`${getLevelColor(training.level)} text-white`}>
                            {training.level}
                          </Badge>
                        </div>
                        <div className="absolute bottom-4 left-4">
                          <div className="flex items-center gap-2 text-white">
                            {getModeIcon(training.mode)}
                            <span className="text-sm">{training.mode}</span>
                          </div>
                        </div>
                      </div>
                      
                      {training.certificate && (
                        <div className="absolute top-4 left-4">
                          <Badge className="bg-yellow-500 text-white">
                            <Award className="w-3 h-3 mr-1" />
                            Sertifikat
                          </Badge>
                        </div>
                      )}
                    </div>
                    
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm text-gray-600">{training.rating}</span>
                          <span className="text-sm text-gray-400">• {training.participants}/{training.maxParticipants} peserta</span>
                        </div>
                        <div className="text-lg font-bold text-purple-600">
                          Rp {training.price.toLocaleString('id-ID')}
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-white mb-2">{training.title}</h3>
                      <p className="text-purple-100 text-sm mb-4">{training.description}</p>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2 text-sm text-purple-200">
                          <User className="w-4 h-4" />
                          <span>Pengajar: {training.instructor}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-purple-200">
                          <Clock className="w-4 h-4" />
                          <span>{training.duration} • {training.schedule}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-purple-200">
                          <Calendar className="w-4 h-4" />
                          <span>{training.time}</span>
                        </div>
                      </div>
                      
                      {/* Highlights */}
                      <div className="mb-4">
                        <h4 className="text-sm font-semibold text-white mb-2">Materi Utama:</h4>
                        <div className="flex flex-wrap gap-1">
                          {training.highlights.map((highlight, idx) => (
                            <Badge key={idx} variant="secondary" className="bg-purple-500/20 text-purple-200 text-xs">
                              {highlight}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      {/* Progress */}
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-sm text-purple-200">Ketersediaan</span>
                        <span className="text-sm text-purple-200">{Math.round((training.participants / training.maxParticipants) * 100)}%</span>
                      </div>
                      <div className="w-full bg-white/20 rounded-full h-2 mb-4">
                        <div 
                          className="bg-white h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${(training.participants / training.maxParticipants) * 100}%` }}
                        ></div>
                      </div>
                      
                      <Button className="w-full bg-white text-purple-600 hover:bg-purple-50">
                        Daftar Sekarang
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'completed' && (
            <div className="space-y-8">
              <h2 className="text-2xl font-bold text-white">Pelatihan Selesai</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                {completedTrainings.map((training) => (
                  <Card key={training.id} className="bg-white/10 backdrop-blur-sm border-white/20">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-semibold text-white">{training.title}</h3>
                            {training.certificate && (
                              <Badge className="bg-yellow-500 text-white">
                                <Award className="w-3 h-3 mr-1" />
                                Sertifikat
                              </Badge>
                            )}
                          </div>
                          <p className="text-purple-100 text-sm mb-2">{training.description}</p>
                          <p className="text-purple-200 text-xs">Pengajar: {training.instructor}</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-1 mb-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-white text-sm">{training.rating}</span>
                          </div>
                          <p className="text-purple-200 text-xs">Selesai: {training.completedDate}</p>
                        </div>
                      </div>
                      
                      {/* Progress and Score */}
                      <div className="space-y-3 mb-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-purple-200">Progress</span>
                          <span className="text-sm text-white">{training.progress}%</span>
                        </div>
                        <Progress value={training.progress} className="h-2" />
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-purple-200">Nilai Akhir</span>
                          <span className="text-sm text-white font-semibold">{training.score}/100</span>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent border-white text-white hover:bg-white/20">
                          <Play className="w-4 h-4 mr-1" />
                          Ulangi
                        </Button>
                        {training.certificate && (
                          <Button variant="outline" size="sm" className="flex-1 bg-transparent border-white text-white hover:bg-white/20">
                            <Award className="w-4 h-4 mr-1" />
                            Sertifikat
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'instructors' && (
            <div className="space-y-8">
              <h2 className="text-2xl font-bold text-white">Tim Instruktur</h2>
              
              <div className="grid md:grid-cols-3 gap-6">
                {instructors.map((instructor, index) => (
                  <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 text-center hover:bg-white/20 transition-colors">
                    <CardContent className="p-6">
                      <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-cyan-400 rounded-full mx-auto mb-4 flex items-center justify-center">
                        <span className="text-2xl font-bold text-white">{instructor.name.charAt(0)}</span>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-white mb-2">{instructor.name}</h3>
                      <p className="text-purple-200 text-sm mb-4">{instructor.expertise}</p>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center justify-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm text-white">{instructor.rating}</span>
                        </div>
                        <p className="text-xs text-purple-300">{instructor.experience} pengalaman</p>
                        <p className="text-xs text-purple-300">{instructor.students}+ murid</p>
                        <p className="text-xs text-purple-300">{instructor.courses} kursus</p>
                      </div>
                      
                      <p className="text-sm text-purple-100 mb-4">{instructor.bio}</p>
                      
                      <Button className="w-full bg-white text-purple-600 hover:bg-purple-50">
                        Lihat Profil
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl font-bold text-white mb-4">Ingin Menjadi Instruktur?</h3>
          <p className="text-lg text-purple-100 mb-6">
            Bagikan pengetahuan dan pengalaman Anda dengan komunitas UMKM. Dapatkan penghasilan tambahan dan bangun personal branding Anda!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-purple-50">
              <Target className="w-5 h-5 mr-2" />
              Daftar sebagai Pengajar
            </Button>
            <Button variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white/20">
              <BookOpen className="w-5 h-5 mr-2" />
              Panduan Mengajar
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}