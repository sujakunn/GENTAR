/**
 * Messages page for real-time chat between users
 * Features conversation list, chat interface, and file sharing
 */

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ArrowLeft, Search, Send, Paperclip, Smile, MoreVertical, Phone, Video, Info } from 'lucide-react'
import { Link } from 'react-router'
import { useAuthStore } from '@/store/authStore'

interface Message {
  id: string
  senderId: string
  receiverId: string
  content: string
  timestamp: string
  read: boolean
}

interface Conversation {
  id: string
  userId: string
  userName: string
  userAvatar?: string
  lastMessage: string
  lastMessageTime: string
  unreadCount: number
  isOnline: boolean
}

export default function MessagesPage() {
  const { user } = useAuthStore()
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: '1',
      userId: '2',
      userName: 'Ahmad Fauzi',
      userAvatar: '',
      lastMessage: 'Terima kasih atas informasinya',
      lastMessageTime: '10:30',
      unreadCount: 2,
      isOnline: true
    },
    {
      id: '2',
      userId: '3',
      userName: 'Siti Nurhaliza',
      userAvatar: '',
      lastMessage: 'Produk sudah sampai dengan selamat',
      lastMessageTime: 'Kemarin',
      unreadCount: 0,
      isOnline: false
    },
    {
      id: '3',
      userId: '4',
      userName: 'Budi Santoso',
      userAvatar: '',
      lastMessage: 'Apakah masih ada stok?',
      lastMessageTime: '2 hari yang lalu',
      unreadCount: 1,
      isOnline: true
    }
  ])
  
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (activeConversation) {
      // Load messages for active conversation
      setMessages([
        {
          id: '1',
          senderId: activeConversation.userId,
          receiverId: user?.id || '',
          content: 'Halo, saya tertarik dengan produk Anda',
          timestamp: '10:00',
          read: true
        },
        {
          id: '2',
          senderId: user?.id || '',
          receiverId: activeConversation.userId,
          content: 'Halo! Terima kasih atas minat Anda. Ada yang bisa saya bantu?',
          timestamp: '10:05',
          read: true
        },
        {
          id: '3',
          senderId: activeConversation.userId,
          receiverId: user?.id || '',
          content: 'Saya ingin bertanya tentang stok produk',
          timestamp: '10:15',
          read: true
        },
        {
          id: '4',
          senderId: user?.id || '',
          receiverId: activeConversation.userId,
          content: 'Tentu, stok masih tersedia. Anda mau pesan berapa?',
          timestamp: '10:20',
          read: true
        },
        {
          id: '5',
          senderId: activeConversation.userId,
          receiverId: user?.id || '',
          content: 'Terima kasih atas informasinya',
          timestamp: '10:30',
          read: false
        }
      ])
    }
  }, [activeConversation, user])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSendMessage = () => {
    if (newMessage.trim() && activeConversation && user) {
      const message: Message = {
        id: Date.now().toString(),
        senderId: user.id,
        receiverId: activeConversation.userId,
        content: newMessage,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        read: false
      }
      
      setMessages([...messages, message])
      setNewMessage('')
      
      // Update conversation last message
      setConversations(conversations.map(conv => 
        conv.id === activeConversation.id
          ? { ...conv, lastMessage: newMessage, lastMessageTime: 'Baru saja', unreadCount: 0 }
          : conv
      ))
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const filteredConversations = conversations.filter(conv =>
    conv.userName.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <Send className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Silakan Masuk</h2>
          <p className="text-purple-100 mb-6">Anda perlu masuk untuk mengakses pesan</p>
          <Link to="/auth">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Masuk Sekarang
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-white">Pesan</h1>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 h-[calc(100vh-120px)]">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
          {/* Conversation List */}
          <div className="md:col-span-1 flex flex-col">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20 flex-1 flex flex-col">
              <CardHeader className="pb-3">
                <CardTitle className="text-white">Percakapan</CardTitle>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-4 h-4" />
                  <Input
                    placeholder="Cari percakapan..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                  />
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto p-0">
                <div className="space-y-1">
                  {filteredConversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      className={`p-4 hover:bg-white/10 cursor-pointer transition-colors ${
                        activeConversation?.id === conversation.id ? 'bg-white/20' : ''
                      }`}
                      onClick={() => setActiveConversation(conversation)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={conversation.userAvatar} />
                            <AvatarFallback className="bg-purple-500 text-white">
                              {conversation.userName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          {conversation.isOnline && (
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white/10"></div>
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h3 className="font-semibold text-white truncate">{conversation.userName}</h3>
                            <span className="text-xs text-purple-200">{conversation.lastMessageTime}</span>
                          </div>
                          <p className="text-sm text-purple-200 truncate">{conversation.lastMessage}</p>
                        </div>
                        
                        {conversation.unreadCount > 0 && (
                          <Badge className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center p-0">
                            {conversation.unreadCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Interface */}
          <div className="md:col-span-2 flex flex-col">
            {activeConversation ? (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 flex-1 flex flex-col">
                {/* Chat Header */}
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={activeConversation.userAvatar} />
                        <AvatarFallback className="bg-purple-500 text-white">
                          {activeConversation.userName.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-white text-lg">{activeConversation.userName}</CardTitle>
                        <CardDescription className="text-purple-200">
                          {activeConversation.isOnline ? 'Online' : 'Offline'}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                        <Phone className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                        <Video className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                        <Info className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.senderId === user?.id ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          message.senderId === user?.id
                            ? 'bg-white text-purple-600'
                            : 'bg-white/20 text-white'
                        }`}
                      >
                        <p>{message.content}</p>
                        <p className={`text-xs mt-1 ${
                          message.senderId === user?.id ? 'text-purple-400' : 'text-purple-200'
                        }`}>
                          {message.timestamp}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </CardContent>

                {/* Message Input */}
                <div className="p-4 border-t border-white/20">
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                      <Paperclip className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                      <Smile className="w-4 h-4" />
                    </Button>
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Ketik pesan..."
                      className="flex-1 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim()}
                      className="bg-white text-purple-600 hover:bg-purple-50"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Send className="w-16 h-16 text-purple-200 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Pilih Percakapan</h3>
                  <p className="text-purple-100">Pilih percakapan dari daftar untuk memulai chat</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
