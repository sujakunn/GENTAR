
/**
 * Marketplace page for UMKM Tangerang Gemilang
 * Features product listings, categories, search, and shopping cart functionality
 */

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Search, Filter, ShoppingCart, Star, Heart } from 'lucide-react'
import Header from '@/components/layout/Header'
import { useCartStore } from '@/store/cartStore'
import { useAuthStore } from '@/store/authStore'
import { Link, useNavigate } from 'react-router'

export default function Marketplace() {
  const navigate = useNavigate()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Semua')
  const { addItem, clearCart } = useCartStore()
  const { isAuthenticated, user } = useAuthStore()
  const [addingToCart, setAddingToCart] = useState<string | null>(null)

  const handleAddToCart = async (product: any) => {
    try {
      console.log('Adding to cart:', product)
      console.log('Is authenticated:', isAuthenticated)
      
      if (!isAuthenticated) {
        console.log('User not authenticated, redirecting to login')
        navigate('/auth')
        return
      }

      setAddingToCart(product.id)
      
      console.log('Adding item to cart...')
      await new Promise(resolve => setTimeout(resolve, 500)) // Simulate API call
      
      const cartItem = {
        id: product.id.toString(),
        name: product.name,
        price: product.price,
        image: `https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/f4a77a09-7efa-4e41-8aa5-3dfe136f905e.jpg`,
        seller: product.seller,
        sellerId: '1', // Mock seller ID
        category: product.category
      }
      
      console.log('Cart item:', cartItem)
      addItem(cartItem)
      console.log('Item added successfully')
      
      // Show success notification
      showNotification(`${product.name} berhasil ditambahkan ke keranjang!`, 'success')
      
      // Auto redirect to cart after adding item
      setTimeout(() => {
        navigate('/cart')
      }, 1000)
    } catch (error) {
      console.error('Failed to add to cart:', error)
      showNotification('Gagal menambahkan ke keranjang', 'error')
    } finally {
      setAddingToCart(null)
    }
  }

  const handleBuyNow = async (product: any) => {
    try {
      console.log('Buy now for product:', product)
      console.log('Is authenticated:', isAuthenticated)
      
      if (!isAuthenticated) {
        console.log('User not authenticated, redirecting to login')
        navigate('/auth')
        return
      }

      // Clear cart first
      clearCart()
      
      // Add product to cart
      const cartItem = {
        id: product.id.toString(),
        name: product.name,
        price: product.price,
        image: `https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/f4a77a09-7efa-4e41-8aa5-3dfe136f905e.jpg`,
        seller: product.seller,
        sellerId: '1',
        category: product.category
      }
      
      addItem(cartItem)
      
      // Show notification
      showNotification(`${product.name} ditambahkan ke keranjang`, 'success')
      
      // Redirect to checkout
      setTimeout(() => {
        navigate('/checkout')
      }, 1000)
    } catch (error) {
      console.error('Failed to process buy now:', error)
      showNotification('Gagal memproses pembelian', 'error')
    }
  }

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    const notification = document.createElement('div')
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300 ${
      type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
    }`
    notification.innerHTML = `
      <div class="flex items-center gap-2">
        ${type === 'success' ? 
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>' :
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>'
        }
        <span>${message}</span>
      </div>
    `
    document.body.appendChild(notification)
    
    // Animate in
    setTimeout(() => {
      notification.classList.remove('translate-x-full')
    }, 100)
    
    // Remove after 3 seconds
    setTimeout(() => {
      notification.classList.add('translate-x-full')
      setTimeout(() => {
        if (document.body.contains(notification)) {
          document.body.removeChild(notification)
        }
      }, 300)
    }, 3000)
  }

  const categories = ['Semua', 'Makanan', 'Minuman', 'Kerajinan', 'Fashion', 'Elektronik']

  const products = [
    {
      id: 1,
      name: 'Keripik Pisang Premium',
      price: 25000,
      rating: 4.8,
      category: 'Makanan',
      description: 'Keripik pisang renyah dengan rasa original',
      seller: 'UMKM Pisang Jaya'
    },
    {
      id: 2,
      name: 'Madu Hutan Murni',
      price: 85000,
      rating: 4.9,
      category: 'Minuman',
      description: 'Madu alami dari hutan Tangerang',
      seller: 'UMKM Madu Sejahtera'
    },
    {
      id: 3,
      name: 'Tas Anyaman Bambu',
      price: 120000,
      rating: 4.7,
      category: 'Kerajinan',
      description: 'Tas anyaman bambu eco-friendly',
      seller: 'UMKM Bambu Kreatif'
    },
    {
      id: 4,
      name: 'Batik Tangerang',
      price: 150000,
      rating: 4.9,
      category: 'Fashion',
      description: 'Kain batik khas Tangerang',
      seller: 'UMKM Batik Gemilang'
    },
    {
      id: 5,
      name: 'Kue Lumpur Tradisional',
      price: 35000,
      rating: 4.6,
      category: 'Makanan',
      description: 'Kue lumpur dengan resep turun temurun',
      seller: 'UMKM Kue Tradisional'
    },
    {
      id: 6,
      name: 'Lampu Hias Bamboo',
      price: 95000,
      rating: 4.5,
      category: 'Elektronik',
      description: 'Lampu hias dari bambu alami',
      seller: 'UMMW Bamboo Craft'
    }
  ]

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'Semua' || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <Header />

      {/* Search and Filter Section */}
      <section className="py-6 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-5 h-5" />
              <Input
                placeholder="Cari produk UMKM..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
              />
            </div>
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={`whitespace-nowrap ${
                  selectedCategory === category 
                    ? "bg-white text-purple-600" 
                    : "bg-transparent border-white text-white hover:bg-white/20"
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">
              {selectedCategory === 'Semua' ? 'Semua Produk' : `Produk ${selectedCategory}`}
            </h2>
            <span className="text-purple-100">{filteredProducts.length} produk ditemukan</span>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <div key={product.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <div className="relative">
                  <img 
                    src={`https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/f4a77a09-7efa-4e41-8aa5-3dfe136f905e.jpg`} 
                    alt={product.name}
                    className="w-full h-48 object-cover"
                  />
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute top-2 right-2 bg-white/80 hover:bg-white text-purple-600"
                  >
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs bg-purple-100 text-purple-600 px-2 py-1 rounded-full">
                      {product.category}
                    </span>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm text-gray-600">{product.rating}</span>
                    </div>
                  </div>
                  
                  <h3 className="font-semibold text-gray-800 mb-2 line-clamp-1">{product.name}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{product.description}</p>
                  <p className="text-xs text-gray-500 mb-3"> oleh {product.seller}</p>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-purple-600">
                      Rp {product.price.toLocaleString('id-ID')}
                    </span>
                    <Button 
                      size="sm" 
                      className="bg-purple-600 hover:bg-purple-700"
                      onClick={() => handleAddToCart(product)}
                      disabled={addingToCart === product.id}
                    >
                      {addingToCart === product.id ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-1" />
                          Memproses...
                        </>
                      ) : (
                        <>
                          <ShoppingCart className="w-4 h-4 mr-1" />
                          Beli
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <ShoppingCart className="w-16 h-16 text-purple-200 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Produk tidak ditemukan</h3>
              <p className="text-purple-100">Coba kata kunci pencarian lain atau kategori berbeda</p>
            </div>
          )}
        </div>
      </section>

      {/* Featured Sellers */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8">Penjual Unggulan</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {['UMKM Pisang Jaya', 'UMKM Madu Sejahtera', 'UMKM Bambu Kreatif', 'UMKM Batik Gemilang'].map((seller, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-purple-400 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-xl font-bold text-white">{seller.charAt(0)}</span>
                </div>
                <h3 className="font-semibold text-white mb-2">{seller}</h3>
                <div className="flex items-center justify-center gap-1 mb-2">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm text-purple-100">4.8 (124 ulasan)</span>
                </div>
                <p className="text-sm text-purple-100">152 produk terjual</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
