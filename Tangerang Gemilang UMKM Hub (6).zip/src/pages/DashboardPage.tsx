/**
 * Dashboard page for sellers with business analytics and management
 * Provides overview of sales, products, and business performance
 */

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, TrendingUp, Package, Users, DollarSign, Star, Eye, Plus, BarChart3 } from 'lucide-react'
import { Link } from 'react-router'
import { useAuthStore } from '@/store/authStore'

export default function DashboardPage() {
  const { user } = useAuthStore()
  const [timeRange, setTimeRange] = useState('month')

  // Mock data for dashboard
  const stats = {
    totalSales: 12500000,
    totalOrders: 156,
    totalProducts: 24,
    totalCustomers: 89,
    monthlyGrowth: 12.5
  }

  const recentOrders = [
    { id: 'ORD-001', customer: 'Ahmad Fauzi', amount: 250000, status: 'completed', date: '2024-01-15' },
    { id: 'ORD-002', customer: 'Siti Nurhaliza', amount: 85000, status: 'processing', date: '2024-01-14' },
    { id: 'ORD-003', customer: 'Budi Santoso', amount: 120000, status: 'shipped', date: '2024-01-13' },
    { id: 'ORD-004', customer: 'Dewi Lestari', amount: 350000, status: 'completed', date: '2024-01-12' }
  ]

  const topProducts = [
    { name: 'Keripik Pisang Premium', sales: 45, revenue: 1125000, rating: 4.8 },
    { name: 'Madu Hutan Murni', sales: 32, revenue: 2720000, rating: 4.9 },
    { name: 'Tas Anyaman Bambu', sales: 18, revenue: 2160000, rating: 4.7 },
    { name: 'Batik Tangerang', sales: 12, revenue: 1800000, rating: 4.9 }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500'
      case 'processing': return 'bg-yellow-500'
      case 'shipped': return 'bg-blue-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Selesai'
      case 'processing': return 'Diproses'
      case 'shipped': return 'Dikirim'
      default: return 'Pending'
    }
  }

  if (!user || user.role !== 'seller') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <BarChart3 className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Akses Ditolak</h2>
          <p className="text-purple-100 mb-6">Hanya penjual yang dapat mengakses dashboard</p>
          <Link to="/">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Kembali ke Beranda
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-white">Dashboard</h1>
                <p className="text-purple-200">{user.businessName}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={timeRange === 'week' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTimeRange('week')}
                className={timeRange === 'week' ? 'bg-white text-purple-600' : 'bg-transparent border-white text-white hover:bg-white/20'}
              >
                Mingguan
              </Button>
              <Button
                variant={timeRange === 'month' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTimeRange('month')}
                className={timeRange === 'month' ? 'bg-white text-purple-600' : 'bg-transparent border-white text-white hover:bg-white/20'}
              >
                Bulanan
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Total Penjualan</p>
                  <p className="text-2xl font-bold text-white">Rp {stats.totalSales.toLocaleString('id-ID')}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-green-400">+{stats.monthlyGrowth}%</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Total Pesanan</p>
                  <p className="text-2xl font-bold text-white">{stats.totalOrders}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-green-400">+8.2%</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Total Produk</p>
                  <p className="text-2xl font-bold text-white">{stats.totalProducts}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-green-400">+3 produk</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Pelanggan</p>
                  <p className="text-2xl font-bold text-white">{stats.totalCustomers}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-green-400">+15 pelanggan</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Tabs defaultValue="orders" className="space-y-6">
              <TabsList className="bg-white/10 border-white/20">
                <TabsTrigger value="orders" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
                  Pesanan Terbaru
                </TabsTrigger>
                <TabsTrigger value="products" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
                  Produk Terlaris
                </TabsTrigger>
              </TabsList>

              <TabsContent value="orders">
                <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white">Pesanan Terbaru</CardTitle>
                    <CardDescription className="text-purple-200">
                      Daftar pesanan terbaru dari pelanggan
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentOrders.map((order) => (
                        <div key={order.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                          <div className="flex items-center gap-4">
                            <div>
                              <h4 className="font-semibold text-white">{order.id}</h4>
                              <p className="text-sm text-purple-200">{order.customer}</p>
                              <p className="text-xs text-purple-300">{order.date}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-white">Rp {order.amount.toLocaleString('id-ID')}</p>
                            <Badge className={`text-xs ${getStatusColor(order.status)}`}>
                              {getStatusText(order.status)}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 text-center">
                      <Link to="/orders">
                        <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
                          Lihat Semua Pesanan
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="products">
                <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white">Produk Terlaris</CardTitle>
                    <CardDescription className="text-purple-200">
                      Produk dengan penjualan tertinggi bulan ini
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {topProducts.map((product, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                              <Package className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-white">{product.name}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <div className="flex items-center gap-1">
                                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                  <span className="text-sm text-purple-200">{product.rating}</span>
                                </div>
                                <span className="text-sm text-purple-300">• {product.sales} terjual</span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-white">Rp {product.revenue.toLocaleString('id-ID')}</p>
                            <Progress value={(product.sales / 50) * 100} className="w-24 mt-1" />
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 text-center">
                      <Link to="/products">
                        <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
                          Kelola Semua Produk
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Aksi Cepat</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to="/products/new">
                  <Button className="w-full bg-white text-purple-600 hover:bg-purple-50">
                    <Plus className="w-4 h-4 mr-2" />
                    Tambah Produk
                  </Button>
                </Link>
                <Link to="/orders">
                  <Button variant="outline" className="w-full bg-transparent border-white text-white hover:bg-white/20">
                    <Eye className="w-4 h-4 mr-2" />
                    Lihat Pesanan
                  </Button>
                </Link>
                <Link to="/analytics">
                  <Button variant="outline" className="w-full bg-transparent border-white text-white hover:bg-white/20">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Lihat Analitik
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Performa Toko</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-purple-200">Rating Toko</span>
                    <span className="text-white">4.8/5.0</span>
                  </div>
                  <Progress value={96} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-purple-200">Respon Time</span>
                    <span className="text-white">95%</span>
                  </div>
                  <Progress value={95} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-purple-200">Kepuasan Pelanggan</span>
                    <span className="text-white">98%</span>
                  </div>
                  <Progress value={98} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}