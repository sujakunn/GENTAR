/**
 * Products management page for sellers
 * Features product CRUD operations, inventory management, and analytics
 */

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { ArrowLeft, Plus, Edit, Trash2, Package, TrendingUp, Eye, Star, Search, Filter } from 'lucide-react'
import { Link } from 'react-router'
import { useAuthStore } from '@/store/authStore'
import { useProductStore, Product } from '@/store/productStore'
import ProductForm from '@/components/product/ProductForm'

export default function ProductsPage() {
  const { user } = useAuthStore()
  const { products, filteredProducts, deleteProduct } = useProductStore()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  // Filter products for current seller
  const sellerProducts = products.filter(product => product.sellerId === user?.id)
  
  // Calculate stats
  const totalProducts = sellerProducts.length
  const totalStock = sellerProducts.reduce((sum, product) => sum + product.stock, 0)
  const averageRating = sellerProducts.length > 0 
    ? sellerProducts.reduce((sum, product) => sum + product.rating, 0) / sellerProducts.length 
    : 0
  const totalViews = 1250 // Mock data

  const categories = ['Makanan', 'Minuman', 'Kerajinan', 'Fashion', 'Elektronik', 'Lainnya']

  const handleDeleteProduct = (productId: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus produk ini?')) {
      deleteProduct(productId)
    }
  }

  const handleEditProduct = (product: Product) => {
    setSelectedProduct(product)
    setIsEditDialogOpen(true)
  }

  if (!user || user.role !== 'seller') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <Package className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Akses Ditolak</h2>
          <p className="text-purple-100 mb-6">Hanya penjual yang dapat mengakses halaman ini</p>
          <Link to="/">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Kembali ke Beranda
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-white">Kelola Produk</h1>
                <p className="text-purple-200">{user.businessName}</p>
              </div>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-white text-purple-600 hover:bg-purple-50">
                  <Plus className="w-4 h-4 mr-2" />
                  Tambah Produk
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Tambah Produk Baru</DialogTitle>
                  <DialogDescription>
                    Isi informasi produk yang ingin Anda tambahkan
                  </DialogDescription>
                </DialogHeader>
                <ProductForm onSuccess={() => setIsAddDialogOpen(false)} />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Total Produk</p>
                  <p className="text-2xl font-bold text-white">{totalProducts}</p>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Total Stok</p>
                  <p className="text-2xl font-bold text-white">{totalStock}</p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Rating Rata-rata</p>
                  <p className="text-2xl font-bold text-white">{averageRating.toFixed(1)}</p>
                </div>
                <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                  <Star className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-200">Total Dilihat</p>
                  <p className="text-2xl font-bold text-white">{totalViews}</p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Eye className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="products" className="space-y-6">
          <TabsList className="bg-white/10 border-white/20">
            <TabsTrigger value="products" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Produk Saya
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Analitik
            </TabsTrigger>
            <TabsTrigger value="inventory" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Inventori
            </TabsTrigger>
          </TabsList>

          <TabsContent value="products">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Daftar Produk</CardTitle>
                    <CardDescription className="text-purple-200">
                      Kelola semua produk Anda
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-4 h-4" />
                      <Input
                        placeholder="Cari produk..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30 w-64"
                      />
                    </div>
                    <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
                      <Filter className="w-4 h-4 mr-2" />
                      Filter
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sellerProducts
                    .filter(product => 
                      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      product.description.toLowerCase().includes(searchTerm.toLowerCase())
                    )
                    .map((product) => (
                    <div key={product.id} className="flex items-center gap-4 p-4 bg-white/5 rounded-lg">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      
                      <div className="flex-1">
                        <h3 className="font-semibold text-white">{product.name}</h3>
                        <p className="text-sm text-purple-200 mb-1">{product.description}</p>
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-purple-200">Stok: {product.stock}</span>
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-purple-200">{product.rating}</span>
                          </div>
                          <Badge variant="secondary" className="bg-purple-500 text-white">
                            {product.category}
                          </Badge>
                        </div>
                      </div>

                      <div className="text-right">
                        <p className="font-semibold text-white">Rp {product.price.toLocaleString('id-ID')}</p>
                        <p className="text-sm text-purple-200">{product.reviews.length} ulasan</p>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditProduct(product)}
                          className="bg-transparent border-white text-white hover:bg-white/20"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteProduct(product.id)}
                          className="bg-transparent border-red-500 text-red-400 hover:bg-red-500/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Performa Produk</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {sellerProducts.slice(0, 5).map((product) => (
                    <div key={product.id} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-white">{product.name}</p>
                        <p className="text-sm text-purple-200">{product.reviews.length} ulasan</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-white">Rp {product.price.toLocaleString('id-ID')}</p>
                        <Progress value={product.rating * 20} className="w-24 mt-1" />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Statistik Penjualan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-200">Produk Terlaris</span>
                      <span className="text-white">Keripik Pisang</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-200">Kategori Terlaris</span>
                      <span className="text-white">Makanan</span>
                    </div>
                    <Progress value={70} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-200">Konversi Penjualan</span>
                      <span className="text-white">12.5%</span>
                    </div>
                    <Progress value={12.5} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="inventory">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Manajemen Inventori</CardTitle>
                <CardDescription className="text-purple-200">
                  Pantau stok produk Anda
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sellerProducts.map((product) => (
                    <div key={product.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                      <div className="flex items-center gap-4">
                        <img 
                          src={product.image} 
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                        <div>
                          <h3 className="font-medium text-white">{product.name}</h3>
                          <p className="text-sm text-purple-200">{product.category}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="font-medium text-white">Stok: {product.stock}</p>
                          <div className="text-sm text-purple-200">
                            {product.stock > 10 ? 'Tersedia' : 'Hampir Habis'}
                          </div>
                        </div>
                        <div className="w-32">
                          <Progress 
                            value={Math.min((product.stock / 50) * 100, 100)} 
                            className="h-2"
                          />
                        </div>
                        <Button variant="outline" size="sm" className="bg-transparent border-white text-white hover:bg-white/20">
                          Edit Stok
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Product Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Produk</DialogTitle>
            <DialogDescription>
              Perbarui informasi produk Anda
            </DialogDescription>
          </DialogHeader>
          {selectedProduct && (
            <ProductForm 
              product={selectedProduct} 
              onSuccess={() => setIsEditDialogOpen(false)} 
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
