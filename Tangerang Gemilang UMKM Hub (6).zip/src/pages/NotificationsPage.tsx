/**
 * Notifications page for managing user notifications
 * Features real-time notifications, settings, and history
 */

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { ArrowLeft, Bell, Settings, CheckCircle, XCircle, Info, ShoppingCart, MessageSquare, Users, Calendar } from 'lucide-react'
import { Link } from 'react-router'
import { useAuthStore } from '@/store/authStore'

interface Notification {
  id: string
  type: 'order' | 'message' | 'community' | 'training' | 'system'
  title: string
  message: string
  timestamp: string
  read: boolean
  action?: {
    label: string
    href: string
  }
}

export default function NotificationsPage() {
  const { user } = useAuthStore()
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'order',
      title: 'Pesanan Baru',
      message: 'Anda mendapatkan pesanan baru untuk Keripik Pisang Premium',
      timestamp: '2 menit yang lalu',
      read: false,
      action: {
        label: 'Lihat Pesanan',
        href: '/orders'
      }
    },
    {
      id: '2',
      type: 'message',
      title: 'Pesan Baru',
      message: 'Ahmad Fauzi mengirimkan pesan kepada Anda',
      timestamp: '1 jam yang lalu',
      read: false,
      action: {
        label: 'Lihat Pesan',
        href: '/messages'
      }
    },
    {
      id: '3',
      type: 'community',
      title: 'Update Komunitas',
      message: 'Ada diskusi baru di forum komunitas',
      timestamp: '3 jam yang lalu',
      read: true,
      action: {
        label: 'Lihat Diskusi',
        href: '/community'
      }
    },
    {
      id: '4',
      type: 'training',
      title: 'Pelatihan Dimulai',
      message: 'Pelatihan Digital Marketing akan dimulai besok',
      timestamp: '1 hari yang lalu',
      read: true,
      action: {
        label: 'Lihat Detail',
        href: '/training'
      }
    },
    {
      id: '5',
      type: 'system',
      title: 'Pembaruan Sistem',
      message: 'Sistem telah diperbarui dengan fitur baru',
      timestamp: '2 hari yang lalu',
      read: true
    }
  ])

  const [notificationSettings, setNotificationSettings] = useState({
    email: true,
    push: true,
    sms: false,
    orderUpdates: true,
    messages: true,
    communityUpdates: true,
    trainingReminders: true,
    promotional: false
  })

  const unreadCount = notifications.filter(n => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ))
  }

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })))
  }

  const deleteNotification = (id: string) => {
    setNotifications(notifications.filter(n => n.id !== id))
  }

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'order': return <ShoppingCart className="w-5 h-5" />
      case 'message': return <MessageSquare className="w-5 h-5" />
      case 'community': return <Users className="w-5 h-5" />
      case 'training': return <Calendar className="w-5 h-5" />
      case 'system': return <Info className="w-5 h-5" />
    }
  }

  const getNotificationColor = (type: Notification['type']) => {
    switch (type) {
      case 'order': return 'bg-blue-500'
      case 'message': return 'bg-green-500'
      case 'community': return 'bg-purple-500'
      case 'training': return 'bg-yellow-500'
      case 'system': return 'bg-gray-500'
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <Bell className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Silakan Masuk</h2>
          <p className="text-purple-100 mb-6">Anda perlu masuk untuk melihat notifikasi</p>
          <Link to="/auth">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Masuk Sekarang
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-white">Notifikasi</h1>
                {unreadCount > 0 && (
                  <Badge className="bg-red-500 text-white">{unreadCount}</Badge>
                )}
              </div>
            </div>
            <Button variant="outline" onClick={markAllAsRead} className="bg-transparent border-white text-white hover:bg-white/20">
              Tandai semua dibaca
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="notifications" className="space-y-6">
          <TabsList className="bg-white/10 border-white/20">
            <TabsTrigger value="notifications" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Notifikasi
            </TabsTrigger>
            <TabsTrigger value="settings" className="text-white data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Pengaturan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notifications">
            <div className="space-y-4">
              {notifications.map((notification) => (
                <Card 
                  key={notification.id} 
                  className={`bg-white/10 backdrop-blur-sm border-white/20 ${!notification.read ? 'border-white/40' : ''}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getNotificationColor(notification.type)}`}>
                        {getNotificationIcon(notification.type)}
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-white">{notification.title}</h3>
                            <p className="text-purple-100 mt-1">{notification.message}</p>
                            <p className="text-sm text-purple-300 mt-2">{notification.timestamp}</p>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {!notification.read && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => markAsRead(notification.id)}
                                className="text-purple-200 hover:text-white"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteNotification(notification.id)}
                              className="text-red-400 hover:text-red-300"
                            >
                              <XCircle className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        
                        {notification.action && (
                          <div className="mt-3">
                            <Link to={notification.action.href}>
                              <Button variant="outline" size="sm" className="bg-transparent border-white text-white hover:bg-white/20">
                                {notification.action.label}
                              </Button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {notifications.length === 0 && (
                <div className="text-center py-12">
                  <Bell className="w-16 h-16 text-purple-200 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Tidak ada notifikasi</h3>
                  <p className="text-purple-100">Anda tidak memiliki notifikasi baru</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Pengaturan Notifikasi</CardTitle>
                <CardDescription className="text-purple-200">
                  Kelola bagaimana Anda menerima notifikasi
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Metode Notifikasi</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">Email</p>
                        <p className="text-sm text-purple-200">Terima notifikasi melalui email</p>
                      </div>
                      <Switch
                        checked={notificationSettings.email}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, email: checked})
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">Push Notification</p>
                        <p className="text-sm text-purple-200">Terima notifikasi di browser</p>
                      </div>
                      <Switch
                        checked={notificationSettings.push}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, push: checked})
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">SMS</p>
                        <p className="text-sm text-purple-200">Terima notifikasi melalui SMS</p>
                      </div>
                      <Switch
                        checked={notificationSettings.sms}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, sms: checked})
                        }
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Jenis Notifikasi</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">Update Pesanan</p>
                        <p className="text-sm text-purple-200">Notifikasi tentang status pesanan</p>
                      </div>
                      <Switch
                        checked={notificationSettings.orderUpdates}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, orderUpdates: checked})
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">Pesan</p>
                        <p className="text-sm text-purple-200">Notifikasi pesan baru</p>
                      </div>
                      <Switch
                        checked={notificationSettings.messages}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, messages: checked})
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">Update Komunitas</p>
                        <p className="text-sm text-purple-200">Notifikasi aktivitas komunitas</p>
                      </div>
                      <Switch
                        checked={notificationSettings.communityUpdates}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, communityUpdates: checked})
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">Reminder Pelatihan</p>
                        <p className="text-sm text-purple-200">Notifikasi jadwal pelatihan</p>
                      </div>
                      <Switch
                        checked={notificationSettings.trainingReminders}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, trainingReminders: checked})
                        }
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white">Promosi</p>
                        <p className="text-sm text-purple-200">Notifikasi promosi dan penawaran</p>
                      </div>
                      <Switch
                        checked={notificationSettings.promotional}
                        onCheckedChange={(checked) => 
                          setNotificationSettings({...notificationSettings, promotional: checked})
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <Button className="bg-white text-purple-600 hover:bg-purple-50">
                    Simpan Pengaturan
                  </Button>
                  <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
                    Reset ke Default
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
