/**
 * About page for UMKM Tangerang Gemilang
 * Provides detailed information about the organization, mission, and team
 */

import { useNavigate } from 'react-router'
import { Button } from '@/components/ui/button'
import { Target, Users, Award } from 'lucide-react'
import Header from '@/components/layout/Header'

export default function About() {
  const navigate = useNavigate()
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            UMKM Tangerang Gemilang
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Membangun Ekosistem Digital untuk Pertumbuhan UMKM di Tangerang
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <Target className="w-8 h-8 text-white" />
                <h3 className="text-2xl font-bold text-white">Visi Kami</h3>
              </div>
              <p className="text-lg text-purple-100 leading-relaxed">
                Menjadi platform terdepan dalam pengembangan UMKM di Tangerang, menciptakan ekosistem digital yang inklusif dan berkelanjutan untuk mendorong pertumbuhan ekonomi lokal.
              </p>
            </div>
            
            <div>
              <div className="flex items-center gap-3 mb-6">
                <Award className="w-8 h-8 text-white" />
                <h3 className="text-2xl font-bold text-white">Misi Kami</h3>
              </div>
              <ul className="text-lg text-purple-100 space-y-3">
                <li>• Memberikan akses pasar yang luas melalui platform digital</li>
                <li>• Meningkatkan kapasitas dan kompetensi pelaku UMKM</li>
                <li>• Membangun komunitas yang solid dan saling mendukung</li>
                <li>• Mendorong inovasi dan kreativitas dalam berwirausaha</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-white mb-4">Nilai-Nilai Kami</h3>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { title: 'Inovasi', desc: 'Terus berinovasi untuk memberikan solusi terbaik' },
              { title: 'Kolaborasi', desc: 'Bekerja sama untuk mencapai tujuan bersama' },
              { title: 'Integritas', desc: 'Bertindak dengan jujur dan transparan' },
              { title: 'Keberlanjutan', desc: 'Membangun untuk jangka panjang yang berkelanjutan' }
            ].map((value, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-white">{index + 1}</span>
                </div>
                <h4 className="text-xl font-semibold text-white mb-2">{value.title}</h4>
                <p className="text-purple-100">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Users className="w-8 h-8 text-white" />
              <h3 className="text-3xl font-bold text-white">Tim Kami</h3>
            </div>
            <p className="text-lg text-purple-100">Dedikasi dan profesionalisme untuk kemajuan UMKM</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((member) => (
              <div key={member} className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
                <div className="w-24 h-24 bg-purple-400 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="w-12 h-12 text-white" />
                </div>
                <h4 className="text-xl font-semibold text-white mb-2">
                  {member === 1 ? 'Ahmad Fauzi' : member === 2 ? 'Siti Nurhaliza' : 'Budi Santoso'}
                </h4>
                <p className="text-purple-200 mb-2">
                  {member === 1 ? 'Founder & CEO' : member === 2 ? 'Head of Community' : 'Training Director'}
                </p>
                <p className="text-purple-100 text-sm">
                  {member === 1 ? 'Pengalaman 10+ tahun dalam pengembangan UMKM' : 
                   member === 2 ? 'Ahli dalam membangun komunitas yang solid' : 
                   'Spesialis pelatihan dan pengembangan kapasitas'}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-white mb-6">Bergabunglah Bersama Kami</h3>
          <p className="text-lg text-purple-100 mb-8">
            Jadilah bagian dari perubahan positif untuk UMKM Tangerang
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-purple-50">
              Daftar sebagai UMKM
            </Button>
            <Button variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white/20">
              Jadi Partner
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}