/**
 * User profile page with personal information and settings
 * Allows users to view and edit their profile information
 */

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Separator } from '@/components/ui/separator'
import { ArrowLeft, User, Mail, Phone, MapPin, Store, Calendar, Edit, Save, Camera } from 'lucide-react'
import { Link } from 'react-router'
import { useAuthStore } from '@/store/authStore'

const profileSchema = z.object({
  name: z.string().min(3, 'Nama minimal 3 karakter'),
  email: z.string().email('Email tidak valid'),
  phone: z.string().min(10, 'Nomor telepon minimal 10 digit'),
  address: z.string().min(10, 'Alamat minimal 10 karakter'),
  businessName: z.string().optional(),
  businessType: z.string().optional()
})

type ProfileFormData = z.infer<typeof profileSchema>

export default function ProfilePage() {
  const { user, updateProfile, isLoading } = useAuthStore()
  const [isEditing, setIsEditing] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors }
  } = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || '',
      email: user?.email || '',
      phone: user?.phone || '',
      address: user?.address || '',
      businessName: user?.businessName || '',
      businessType: user?.businessType || ''
    }
  })

  const onSubmit = async (data: ProfileFormData) => {
    setError('')
    setSuccess('')
    
    const success = await updateProfile(data)
    
    if (success) {
      setSuccess('Profil berhasil diperbarui')
      setIsEditing(false)
    } else {
      setError('Gagal memperbarui profil, silakan coba lagi')
    }
  }

  const handleCancel = () => {
    setIsEditing(false)
    // Reset form to original values
    setValue('name', user?.name || '')
    setValue('email', user?.email || '')
    setValue('phone', user?.phone || '')
    setValue('address', user?.address || '')
    setValue('businessName', user?.businessName || '')
    setValue('businessType', user?.businessType || '')
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <User className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Silakan Masuk</h2>
          <p className="text-purple-100 mb-6">Anda perlu masuk untuk melihat profil</p>
          <Link to="/auth">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Masuk Sekarang
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-white">Profil Saya</h1>
            </div>
            <Button
              onClick={() => setIsEditing(!isEditing)}
              variant={isEditing ? "outline" : "default"}
              className={isEditing ? "bg-transparent border-white text-white hover:bg-white/20" : "bg-white text-purple-600 hover:bg-purple-50"}
            >
              {isEditing ? <Save className="w-4 h-4 mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
              {isEditing ? 'Simpan' : 'Edit'}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {success && (
          <Alert className="mb-6 bg-green-500/20 border-green-500/50">
            <AlertDescription className="text-green-100">{success}</AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid md:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="md:col-span-1">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <div className="text-center">
                  <div className="relative inline-block">
                    <div className="w-32 h-32 bg-purple-400 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <span className="text-4xl font-bold text-white">{user.name.charAt(0)}</span>
                    </div>
                    <Button
                      size="icon"
                      variant="outline"
                      className="absolute bottom-2 right-0 bg-white text-purple-600 hover:bg-purple-50 border-2 border-white"
                    >
                      <Camera className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <h2 className="text-xl font-bold text-white mb-2">{user.name}</h2>
                  <Badge className="mb-4 bg-purple-500 text-white">
                    {user.role === 'seller' ? 'Penjual UMKM' : 'Pembeli'}
                  </Badge>
                  
                  <div className="space-y-2 text-left">
                    <div className="flex items-center gap-2 text-purple-100">
                      <Calendar className="w-4 h-4" />
                      <span className="text-sm">Bergabung {user.joinedAt}</span>
                    </div>
                    {user.businessName && (
                      <div className="flex items-center gap-2 text-purple-100">
                        <Store className="w-4 h-4" />
                        <span className="text-sm">{user.businessName}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Profile Form */}
          <div className="md:col-span-2">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Informasi Pribadi</CardTitle>
                <CardDescription className="text-purple-200">
                  Kelola informasi profil Anda
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-white">Nama Lengkap</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-4 h-4" />
                        <Input
                          id="name"
                          type="text"
                          disabled={!isEditing}
                          {...register('name')}
                          className={`pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 ${errors.name ? 'border-red-500' : ''}`}
                        />
                      </div>
                      {errors.name && (
                        <p className="text-sm text-red-400">{errors.name.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-white">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-4 h-4" />
                        <Input
                          id="email"
                          type="email"
                          disabled={!isEditing}
                          {...register('email')}
                          className={`pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 ${errors.email ? 'border-red-500' : ''}`}
                        />
                      </div>
                      {errors.email && (
                        <p className="text-sm text-red-400">{errors.email.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-white">Nomor Telepon</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-4 h-4" />
                        <Input
                          id="phone"
                          type="tel"
                          disabled={!isEditing}
                          {...register('phone')}
                          className={`pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 ${errors.phone ? 'border-red-500' : ''}`}
                        />
                      </div>
                      {errors.phone && (
                        <p className="text-sm text-red-400">{errors.phone.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address" className="text-white">Alamat</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-4 h-4" />
                        <Input
                          id="address"
                          type="text"
                          disabled={!isEditing}
                          {...register('address')}
                          className={`pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 ${errors.address ? 'border-red-500' : ''}`}
                        />
                      </div>
                      {errors.address && (
                        <p className="text-sm text-red-400">{errors.address.message}</p>
                      )}
                    </div>
                  </div>

                  {user.role === 'seller' && (
                    <>
                      <Separator className="bg-white/20" />
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-white">Informasi Usaha</h3>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="businessName" className="text-white">Nama Usaha</Label>
                            <div className="relative">
                              <Store className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-4 h-4" />
                              <Input
                                id="businessName"
                                type="text"
                                disabled={!isEditing}
                                {...register('businessName')}
                                className={`pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 ${errors.businessName ? 'border-red-500' : ''}`}
                              />
                            </div>
                            {errors.businessName && (
                              <p className="text-sm text-red-400">{errors.businessName.message}</p>
                            )}
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="businessType" className="text-white">Jenis Usaha</Label>
                            <Select 
                              disabled={!isEditing}
                              onValueChange={(value) => setValue('businessType', value)}
                              defaultValue={user.businessType}
                            >
                              <SelectTrigger className="bg-white/20 border-white/30 text-white">
                                <SelectValue placeholder="Pilih jenis usaha" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Food">Makanan</SelectItem>
                                <SelectItem value="Beverage">Minuman</SelectItem>
                                <SelectItem value="Fashion">Fashion</SelectItem>
                                <SelectItem value="Craft">Kerajinan</SelectItem>
                                <SelectItem value="Electronics">Elektronik</SelectItem>
                                <SelectItem value="Services">Jasa</SelectItem>
                                <SelectItem value="Other">Lainnya</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {isEditing && (
                    <div className="flex gap-4 pt-4">
                      <Button type="submit" className="bg-white text-purple-600 hover:bg-purple-50" disabled={isLoading}>
                        {isLoading ? 'Menyimpan...' : 'Simpan Perubahan'}
                      </Button>
                      <Button type="button" variant="outline" onClick={handleCancel} className="bg-transparent border-white text-white hover:bg-white/20">
                        Batal
                      </Button>
                    </div>
                  )}
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}