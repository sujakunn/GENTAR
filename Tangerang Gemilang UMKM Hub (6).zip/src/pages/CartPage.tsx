/**
 * Shopping cart page with item management and checkout
 * Displays cart items, quantities, and checkout process
 */

import { useState } from 'react'
import { useNavigate } from 'react-router'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { ArrowLeft, Minus, Plus, Trash2, ShoppingBag, Loader2 } from 'lucide-react'
import { Link } from 'react-router'
import { useCartStore } from '@/store/cartStore'
import { useAuthStore } from '@/store/authStore'

export default function CartPage() {
  const navigate = useNavigate()
  const { items, totalPrice, updateQuantity, removeItem, clearCart, applyPromoCode } = useCartStore()
  const { isAuthenticated } = useAuthStore()
  const [isApplyingPromo, setIsApplyingPromo] = useState(false)
  const [isCheckoutLoading, setIsCheckoutLoading] = useState(false)
  const [promoCode, setPromoCode] = useState('')
  const [promoDiscount, setPromoDiscount] = useState(0)

  const handleCheckout = async () => {
    try {
      console.log('CartPage - handleCheckout called')
      console.log('Is authenticated:', isAuthenticated)
      console.log('Cart items:', items)
      console.log('Cart items length:', items.length)
      
      if (!isAuthenticated) {
        console.log('User not authenticated, redirecting to login')
        navigate('/auth')
        return
      }
      
      if (items.length === 0) {
        console.log('Cart is empty, showing notification')
        showNotification('Keranjang belanja kosong!', 'error')
        return
      }
      
      // Add loading state
      setIsCheckoutLoading(true)
      
      console.log('Proceeding to checkout')
      
      // Simulate a small delay for better UX
      await new Promise(resolve => setTimeout(resolve, 500))
      
      navigate('/checkout')
    } catch (error) {
      console.error('Error in handleCheckout:', error)
      showNotification('Terjadi kesalahan. Silakan coba lagi.', 'error')
    } finally {
      setIsCheckoutLoading(false)
    }
  }

  const handleApplyPromoCode = async () => {
    if (!promoCode.trim()) {
      showNotification('Masukkan kode promo terlebih dahulu', 'error')
      return
    }

    setIsApplyingPromo(true)
    
    try {
      const result = applyPromoCode(promoCode.trim())
      
      if (result.success) {
        setPromoDiscount(result.discount)
        showNotification(result.message, 'success')
      } else {
        setPromoDiscount(0)
        showNotification(result.message, 'error')
      }
    } catch (error) {
      console.error('Error applying promo code:', error)
      showNotification('Gagal menerapkan kode promo', 'error')
    } finally {
      setIsApplyingPromo(false)
    }
  }

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    const notification = document.createElement('div')
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300 ${
      type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
    }`
    notification.innerHTML = `
      <div class="flex items-center gap-2">
        ${type === 'success' ? 
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>' :
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>'}
        }
        <span>${message}</span>
      </div>
    `
    document.body.appendChild(notification)
    
    // Animate in
    setTimeout(() => {
      notification.classList.remove('translate-x-full')
    }, 100)
    
    // Remove after 3 seconds
    setTimeout(() => {
      notification.classList.add('translate-x-full')
      setTimeout(() => {
        if (document.body.contains(notification)) {
          document.body.removeChild(notification)
        }
      }, 300)
    }, 3000)
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Keranjang Belanja Kosong</h2>
          <p className="text-purple-100 mb-6">Belum ada produk di keranjang Anda</p>
          <Link to="/marketplace">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Mulai Belanja
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link to="/marketplace">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-white">Keranjang Belanja</h1>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Produk ({items.length})</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center gap-4 p-4 bg-white/5 rounded-lg">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{item.name}</h3>
                      <p className="text-sm text-purple-200">oleh {item.seller}</p>
                      <Badge variant="secondary" className="mt-1 bg-purple-500 text-white">
                        {item.category}
                      </Badge>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="bg-transparent border-white text-white hover:bg-white/20"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                        className="w-16 text-center bg-white/20 border-white/30 text-white"
                        min="1"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        className="bg-transparent border-white text-white hover:bg-white/20"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="text-right">
                      <div className="font-semibold text-white">
                        Rp {(item.price * item.quantity).toLocaleString('id-ID')}
                      </div>
                      <div className="text-sm text-purple-200">
                        Rp {item.price.toLocaleString('id-ID')} x {item.quantity}
                      </div>
                    </div>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
                      onClick={() => removeItem(item.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="space-y-4">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Ringkasan Pesanan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between text-purple-100">
                  <span>Subtotal</span>
                  <span>Rp {totalPrice.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-purple-100">
                  <span>Ongkos Kirim</span>
                  <span>Rp 15.000</span>
                </div>
                <div className="flex justify-between text-purple-100">
                  <span>Biaya Layanan</span>
                  <span>Rp 2.000</span>
                </div>
                <Separator className="bg-white/20" />
                <div className="flex justify-between text-lg font-semibold text-white">
                  <span>Total</span>
                  <span>Rp {(totalPrice + 17000).toLocaleString('id-ID')}</span>
                </div>
                
                <Button 
                  className="w-full bg-white text-purple-600 hover:bg-purple-50 mt-4"
                  onClick={handleCheckout}
                  disabled={isCheckoutLoading || items.length === 0}
                >
                  {isCheckoutLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Memproses...
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      Checkout - Rp {((totalPrice + 17000) * (1 - promoDiscount)).toLocaleString('id-ID')}
                    </>
                  )}
                </Button>
                
                {!isAuthenticated && (
                  <p className="text-sm text-purple-200 text-center">
                    Silakan masuk untuk melanjutkan checkout
                  </p>
                )}
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Kode Promo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Input 
                      id="promoCode"
                      placeholder="Masukkan kode promo"
                      className="bg-white/20 border-white/30 text-white placeholder-purple-200"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                    />
                    <Button 
                      variant="outline" 
                      className="bg-transparent border-white text-white hover:bg-white/20"
                      onClick={handleApplyPromoCode}
                      disabled={isApplyingPromo}
                    >
                      {isApplyingPromo ? 'Memproses...' : 'Terapkan'}
                    </Button>
                  </div>
                  
                  {promoDiscount > 0 && (
                    <div className="bg-green-500/20 border border-green-500/50 rounded-lg p-3">
                      <p className="text-green-100 text-sm">
                        🎉 Kode promo berhasil diterapkan! Diskon: {(promoDiscount * 100).toFixed(0)}%
                      </p>
                    </div>
                  )}
                  
                  <div className="text-xs text-purple-200">
                    <p>Kode promo tersedia:</p>
                    <p>• UMKM10 (Diskon 10%)</p>
                    <p>• UMKM20 (Diskon 20%)</p>
                    <p>• WELCOME (Diskon 15% untuk member baru)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
