/**
 * Enhanced Community page for UMKM Tangerang Gemilang
 * Features community discussions, events, member profiles, and networking with modern UI
 */

import { useState } from 'react'
import { useNavigate } from 'react-router'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { 
  Search, 
  MessageSquare, 
  Calendar, 
  Users, 
  Plus, 
  Heart, 
  Share2, 
  TrendingUp,
  MapPin,
  Clock,
  User,
  Star,
  Award,
  Target,
  Lightbulb,
  BookOpen,
  Trophy,
  Gift,
  Eye
} from 'lucide-react'
import Header from '@/components/layout/Header'

export default function Community() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('forum')
  const [searchTerm, setSearchTerm] = useState('')

  const forumPosts = [
    {
      id: 1,
      title: 'Bagaimana cara meningkatkan penjualan online?',
      author: 'Ahmad Fauzi',
      authorAvatar: '',
      category: 'Marketing',
      replies: 23,
      likes: 45,
      views: 234,
      time: '2 jam yang lalu',
      content: 'Saya ingin bertanya tentang strategi pemasaran online yang efektif untuk produk makanan. Apa saja platform yang recommended untuk UMKM?',
      isPinned: true,
      isHot: true
    },
    {
      id: 2,
      title: 'Pengalaman ikut pameran UMKM',
      author: 'Siti Nurhaliza',
      authorAvatar: '',
      category: 'Event',
      replies: 18,
      likes: 67,
      views: 189,
      time: '5 jam yang lalu',
      content: 'Baru saja ikut pameran UMKM di Tangerang, pengalaman yang sangat berharga. Banyak dapat kontak dan pembeli langsung!',
      isPinned: false,
      isHot: true
    },
    {
      id: 3,
      title: 'Tips manajemen keuangan untuk pemula',
      author: 'Budi Santoso',
      authorAvatar: '',
      category: 'Keuangan',
      replies: 31,
      likes: 89,
      views: 456,
      time: '1 hari yang lalu',
      content: 'Mau sharing sedikit tentang pengalaman saya dalam mengelola keuangan usaha. Penting banget untuk pisah keuangan pribadi dan usaha.',
      isPinned: false,
      isHot: false
    },
    {
      id: 4,
      title: 'Cari supplier bahan baku berkualitas',
      author: 'Dewi Lestari',
      authorAvatar: '',
      category: 'Produksi',
      replies: 12,
      likes: 34,
      views: 123,
      time: '1 hari yang lalu',
      content: 'Sedang mencari supplier bahan baku untuk produk kerajinan. Ada yang punya rekomendasi? Harga dan kualitas harus seimbang.',
      isPinned: false,
      isHot: false
    }
  ]

  const events = [
    {
      id: 1,
      title: 'Workshop Digital Marketing',
      date: '15 Oktober 2024',
      time: '09:00 - 12:00',
      location: 'Online (Zoom)',
      participants: 45,
      maxParticipants: 100,
      description: 'Pelajari strategi digital marketing untuk UMKM dengan praktisi berpengalaman',
      image: 'digital marketing workshop',
      price: 'Gratis',
      category: 'Workshop'
    },
    {
      id: 2,
      title: 'Meetup UMKM Tangerang',
      date: '20 Oktober 2024',
      time: '14:00 - 17:00',
      location: 'Kantor UMKM Tangerang',
      participants: 78,
      maxParticipants: 150,
      description: 'Gathering dan networking antar pelaku UMKM Tangerang. Ada sesi sharing dan makan malam!',
      image: 'umkm meetup',
      price: 'Rp 50.000',
      category: 'Networking'
    },
    {
      id: 3,
      title: 'Pelatihan Branding Produk',
      date: '25 Oktober 2024',
      time: '10:00 - 15:00',
      location: 'Hotel Tangerang',
      participants: 32,
      maxParticipants: 50,
      description: 'Ciptakan brand yang kuat dan kemasan yang menarik untuk produk UMKM Anda',
      image: 'branding training',
      price: 'Rp 150.000',
      category: 'Training'
    },
    {
      id: 4,
      title: 'Bazaar UMKM Akhir Tahun',
      date: '30 November 2024',
      time: '09:00 - 21:00',
      location: 'Tangerang City Mall',
      participants: 120,
      maxParticipants: 200,
      description: 'Bazar akhir tahun dengan diskon khusus untuk anggota komunitas UMKM Tangerang',
      image: 'bazaar event',
      price: 'Rp 100.000',
      category: 'Bazaar'
    }
  ]

  const members = [
    { 
      name: 'Ahmad Fauzi', 
      business: 'Keripik Pisang Premium', 
      joined: '2023',
      avatar: '',
      role: 'Admin',
      achievements: ['Top Seller', 'Active Contributor'],
      rating: 4.9
    },
    { 
      name: 'Siti Nurhaliza', 
      business: 'Madu Hutan Murni', 
      joined: '2023',
      avatar: '',
      role: 'Moderator',
      achievements: ['Best Product', 'Community Star'],
      rating: 4.8
    },
    { 
      name: 'Budi Santoso', 
      business: 'Tas Anyaman Bambu', 
      joined: '2024',
      avatar: '',
      role: 'Member',
      achievements: ['Newcomer Award'],
      rating: 4.7
    },
    { 
      name: 'Dewi Lestari', 
      business: 'Batik Tangerang', 
      joined: '2024',
      avatar: '',
      role: 'Member',
      achievements: ['Creative Design'],
      rating: 4.9
    },
    { 
      name: 'Eko Prasetyo', 
      business: 'Kue Lumpur Tradisional', 
      joined: '2024',
      avatar: '',
      role: 'Member',
      achievements: ['Traditional Food Expert'],
      rating: 4.6
    },
    { 
      name: 'Rina Susanti', 
      business: 'Kerajinan Anyaman Pandan', 
      joined: '2024',
      avatar: '',
      role: 'Member',
      achievements: ['Craft Master'],
      rating: 4.8
    }
  ]

  const achievements = [
    { icon: Trophy, title: 'Top Seller', description: 'Penjual terbaik bulan ini', count: 15 },
    { icon: Star, title: 'Community Star', description: 'Kontributor aktif komunitas', count: 28 },
    { icon: Award, title: 'Best Product', description: 'Produk dengan rating tertinggi', count: 12 },
    { icon: Gift, title: 'Newcomer', description: 'Member baru yang berpotensi', count: 8 }
  ]

  const categories = [
    { name: 'Marketing', icon: TrendingUp, color: 'bg-blue-500' },
    { name: 'Keuangan', icon: Target, color: 'bg-green-500' },
    { name: 'Produksi', icon: Lightbulb, color: 'bg-yellow-500' },
    { name: 'Event', icon: Calendar, color: 'bg-purple-500' },
    { name: 'Teknologi', icon: BookOpen, color: 'bg-red-500' },
    { name: 'Hukum', icon: Users, color: 'bg-indigo-500' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Komunitas UMKM Tangerang Gemilang
          </h2>
          <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
            Bergabunglah dengan ekosistem UMKM terbesar di Tangerang. Belajar, berbagi, dan berkembang bersama!
          </p>
          
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">1,234</div>
              <div className="text-purple-100">Anggota Aktif</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">456</div>
              <div className="text-purple-100">Diskusi</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">89</div>
              <div className="text-purple-100">Event</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">2,345</div>
              <div className="text-purple-100">Komentar</div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-2xl font-bold text-white mb-6 text-center">Kategori Diskusi</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category, index) => (
              <div key={index} className={`${category.color} rounded-lg p-4 text-center hover:scale-105 transition-transform cursor-pointer`}>
                <category.icon className="w-8 h-8 text-white mx-auto mb-2" />
                <span className="text-white font-medium">{category.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tabs */}
      <section className="py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex gap-2 border-b border-white/20">
            <Button
              variant={activeTab === 'forum' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('forum')}
              className={`${activeTab === 'forum' ? 'bg-white text-purple-600' : 'text-white hover:bg-white/20'}`}
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              Forum
            </Button>
            <Button
              variant={activeTab === 'events' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('events')}
              className={`${activeTab === 'events' ? 'bg-white text-purple-600' : 'text-white hover:bg-white/20'}`}
            >
              <Calendar className="w-4 h-4 mr-2" />
              Event
            </Button>
            <Button
              variant={activeTab === 'members' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('members')}
              className={`${activeTab === 'members' ? 'bg-white text-purple-600' : 'text-white hover:bg-white/20'}`}
            >
              <Users className="w-4 h-4 mr-2" />
              Anggota
            </Button>
            <Button
              variant={activeTab === 'achievements' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('achievements')}
              className={`${activeTab === 'achievements' ? 'bg-white text-purple-600' : 'text-white hover:bg-white/20'}`}
            >
              <Trophy className="w-4 h-4 mr-2" />
              Prestasi
            </Button>
          </div>
        </div>
      </section>

      {/* Search */}
      <section className="py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-5 h-5" />
            <Input
              placeholder="Cari di komunitas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
            />
          </div>
        </div>
      </section>

      {/* Content based on active tab */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {activeTab === 'forum' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Diskusi Terkini</h2>
                <Button className="bg-white text-purple-600 hover:bg-purple-50">
                  <Plus className="w-4 h-4 mr-2" />
                  Buat Topik
                </Button>
              </div>
              
              <div className="space-y-4">
                {forumPosts.map((post) => (
                  <Card key={post.id} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            {post.isPinned && (
                              <Badge className="bg-red-500 text-white">
                                <Star className="w-3 h-3 mr-1" />
                                Dipin
                              </Badge>
                            )}
                            {post.isHot && (
                              <Badge className="bg-orange-500 text-white">
                                <TrendingUp className="w-3 h-3 mr-1" />
                                Hot
                              </Badge>
                            )}
                            <Badge className="bg-purple-500 text-white">
                              {post.category}
                            </Badge>
                            <span className="text-sm text-purple-200">{post.time}</span>
                          </div>
                          <h3 className="text-lg font-semibold text-white mb-2">{post.title}</h3>
                          <p className="text-purple-100 mb-3">{post.content}</p>
                          <div className="flex items-center gap-4 text-sm text-purple-200">
                            <div className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              <span>{post.author}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              <span>{post.views} dilihat</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between pt-4 border-t border-white/20">
                        <div className="flex items-center gap-4">
                          <Button variant="ghost" size="sm" className="text-purple-200 hover:text-white">
                            <Heart className="w-4 h-4 mr-1" />
                            {post.likes}
                          </Button>
                          <Button variant="ghost" size="sm" className="text-purple-200 hover:text-white">
                            <MessageSquare className="w-4 h-4 mr-1" />
                            {post.replies} balasan
                          </Button>
                          <Button variant="ghost" size="sm" className="text-purple-200 hover:text-white">
                            <Share2 className="w-4 h-4 mr-1" />
                            Bagikan
                          </Button>
                        </div>
                        <Button variant="outline" size="sm" className="bg-transparent border-white text-white hover:bg-white/20">
                          Lihat Detail
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'events' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">Event Mendatang</h2>
                <Button className="bg-white text-purple-600 hover:bg-purple-50">
                  <Plus className="w-4 h-4 mr-2" />
                  Buat Event
                </Button>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {events.map((event) => (
                  <Card key={event.id} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-colors overflow-hidden">
                    <div className="h-48 bg-gradient-to-r from-purple-500 to-cyan-400 relative">
                      <div className="absolute top-4 right-4">
                        <Badge className="bg-white text-purple-600">
                          {event.category}
                        </Badge>
                      </div>
                      <div className="absolute bottom-4 left-4 text-white">
                        <div className="text-2xl font-bold">{event.price}</div>
                      </div>
                    </div>
                    
                    <CardContent className="p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Calendar className="w-5 h-5 text-white" />
                        <span className="text-sm text-purple-200">{event.date}</span>
                        <Clock className="w-5 h-5 text-white ml-4" />
                        <span className="text-sm text-purple-200">{event.time}</span>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-white mb-2">{event.title}</h3>
                      <p className="text-purple-100 mb-4">{event.description}</p>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="w-4 h-4 text-purple-200" />
                          <span className="text-purple-200">{event.location}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Users className="w-4 h-4 text-purple-200" />
                          <span className="text-purple-200">{event.participants}/{event.maxParticipants} peserta</span>
                        </div>
                      </div>
                      
                      <div className="w-full bg-white/20 rounded-full h-2 mb-4">
                        <div 
                          className="bg-white h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${(event.participants / event.maxParticipants) * 100}%` }}
                        ></div>
                      </div>
                      
                      <Button className="w-full bg-white text-purple-600 hover:bg-purple-50">
                        Daftar Sekarang
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'members' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white">Anggota Komunitas</h2>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {members.map((member, index) => (
                  <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <Avatar className="w-16 h-16">
                          <AvatarFallback className="bg-purple-500 text-white text-xl">
                            {member.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-white">{member.name}</h3>
                          <p className="text-sm text-purple-200">{member.business}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm text-purple-200">{member.rating}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2 mb-4">
                        <Badge className={`${member.role === 'Admin' ? 'bg-red-500' : member.role === 'Moderator' ? 'bg-blue-500' : 'bg-gray-500'} text-white`}>
                          {member.role}
                        </Badge>
                        <p className="text-xs text-purple-300">Bergabung {member.joined}</p>
                      </div>
                      
                      <div className="flex flex-wrap gap-1 mb-4">
                        {member.achievements.map((achievement, idx) => (
                          <Badge key={idx} variant="secondary" className="bg-purple-500/20 text-purple-200 text-xs">
                            {achievement}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent border-white text-white hover:bg-white/20">
                          Profil
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent border-white text-white hover:bg-white/20">
                          Pesan
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'achievements' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-white">Prestasi Komunitas</h2>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {achievements.map((achievement, index) => (
                  <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 text-center">
                    <CardContent className="p-6">
                      <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <achievement.icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-white mb-2">{achievement.title}</h3>
                      <p className="text-sm text-purple-200 mb-3">{achievement.description}</p>
                      <div className="text-2xl font-bold text-yellow-400">{achievement.count}</div>
                      <p className="text-xs text-purple-300">penerima</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Leaderboard Bulan Ini</CardTitle>
                  <CardDescription className="text-purple-200">Top 5 kontributor teraktif</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {members.slice(0, 5).map((member, index) => (
                      <div key={index} className="flex items-center gap-4">
                        <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-white font-bold">
                          {index + 1}
                        </div>
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-purple-500 text-white">
                            {member.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <h4 className="font-semibold text-white">{member.name}</h4>
                          <p className="text-sm text-purple-200">{member.business}</p>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-white">{Math.floor(Math.random() * 1000) + 500}</div>
                          <div className="text-xs text-purple-200">poin</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}