
/**
 * Professional payment status tracking page
 * Features real-time payment status, QR codes, and payment instructions
 */

import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  ArrowLeft, 
  CheckCircle, 
  Clock, 
  XCircle, 
  RefreshCw, 
  Download,
  Copy,
  QrCode,
  Smartphone,
  Bank,
  CreditCard,
  Package
} from 'lucide-react'
import { Link } from 'react-router'
import { usePaymentStore } from '@/store/paymentStore'
import { useOrderStore } from '@/store/orderStore'

export default function PaymentStatusPage() {
  const { transactionId } = useParams<{ transactionId: string }>()
  const navigate = useNavigate()
  const { transactions, checkPaymentStatus, isLoading: paymentLoading } = usePaymentStore()
  const { orders } = useOrderStore()
  
  const [countdown, setCountdown] = useState('')
  const [copied, setCopied] = useState(false)

  const transaction = transactions.find(t => t.id === transactionId)
  const order = orders.find(o => o.id === transaction?.orderId)
  
  // Debug logging
  console.log('Transaction ID:', transactionId)
  console.log('Found Transaction:', transaction)
  console.log('All Transactions:', transactions)
  console.log('Found Order:', order)

  useEffect(() => {
    console.log('PaymentStatusPage - Transaction:', transaction)
    console.log('PaymentStatusPage - Transaction ID:', transactionId)
    console.log('PaymentStatusPage - All Transactions:', transactions)
    
    if (!transaction) {
      console.log('No transaction found, redirecting to orders')
      navigate('/orders')
      return
    }

    // Check payment status every 10 seconds for pending transactions
    const interval = setInterval(() => {
      if (transaction.status === 'pending') {
        console.log('Checking payment status for:', transaction.id)
        checkPaymentStatus(transaction.id)
      }
    }, 10000)

    // Update countdown
    const updateCountdown = () => {
      if (transaction.expiryDate && transaction.status === 'pending') {
        const expiry = new Date(transaction.expiryDate).getTime()
        const now = new Date().getTime()
        const diff = expiry - now

        if (diff > 0) {
          const hours = Math.floor(diff / (1000 * 60 * 60))
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
          const seconds = Math.floor((diff % (1000 * 60)) / 1000)
          setCountdown(`${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`)
        } else {
          setCountdown('Waktu habis')
        }
      }
    }

    updateCountdown()
    const countdownInterval = setInterval(updateCountdown, 1000)

    // Show notification when payment is successful
    if (transaction.status === 'success') {
      showNotification('Pembayaran berhasil! Pesanan Anda sedang diproses.', 'success')
      
      // Auto redirect to orders after 3 seconds
      const redirectTimer = setTimeout(() => {
        navigate('/orders')
      }, 3000)
      
      return () => {
        clearInterval(interval)
        clearInterval(countdownInterval)
        clearTimeout(redirectTimer)
      }
    }

    return () => {
      clearInterval(interval)
      clearInterval(countdownInterval)
    }
  }, [transaction, checkPaymentStatus, navigate, transactions, transactionId])

  const handleCopyVA = () => {
    if (transaction?.vaNumber) {
      navigator.clipboard.writeText(transaction.vaNumber)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      showNotification('Nomor VA berhasil disalin!', 'success')
    }
  }

  const handleDownloadQR = () => {
    // Generate QR code for payment
    if (transaction) {
      const qrData = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(transaction.transactionId + '|' + transaction.amount)}`
      
      // Create download link
      const link = document.createElement('a')
      link.href = qrData
      link.download = `QR-Payment-${transaction.transactionId}.png`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      
      showNotification('QR Code berhasil diunduh!', 'success')
    }
  }

  const handleRefreshStatus = () => {
    if (transaction) {
      checkPaymentStatus(transaction.id)
      showNotification('Memeriksa status pembayaran...', 'success')
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-500'
      case 'pending': return 'bg-yellow-500'
      case 'processing': return 'bg-blue-500'
      case 'failed': return 'bg-red-500'
      case 'cancelled': return 'bg-gray-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-5 h-5" />
      case 'pending': return <Clock className="w-5 h-5" />
      case 'processing': return <RefreshCw className="w-5 h-5" />
      case 'failed': return <XCircle className="w-5 h-5" />
      case 'cancelled': return <XCircle className="w-5 h-5" />
      default: return <Clock className="w-5 h-5" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'success': return 'Pembayaran Berhasil'
      case 'pending': return 'Menunggu Pembayaran'
      case 'processing': return 'Memproses Pembayaran'
      case 'failed': return 'Pembayaran Gagal'
      case 'cancelled': return 'Dibatalkan'
      default: return 'Status Tidak Diketahui'
    }
  }

  const getPaymentInstructions = () => {
    if (!transaction) return null

    const method = transaction.paymentMethod
    
    if (method.includes('_va')) {
      return {
        title: 'Instruksi Pembayaran Virtual Account',
        steps: [
          'Salin nomor Virtual Account di atas',
          'Buka aplikasi m-banking atau ATM',
          'Pilih menu Transfer ke Virtual Account',
          'Masukkan nomor VA dan jumlah pembayaran',
          'Konfirmasi pembayaran'
        ]
      }
    } else if (method === 'gopay' || method === 'ovo' || method === 'dana') {
      return {
        title: 'Instruksi Pembayaran E-Wallet',
        steps: [
          'Buka aplikasi E-Wallet Anda',
          'Pilih menu Bayar atau Scan QR Code',
          'Scan QR Code yang tersedia',
          'Masukkan jumlah pembayaran',
          'Konfirmasi pembayaran'
        ]
      }
    } else if (method === 'credit_card') {
      return {
        title: 'Instruksi Pembayaran Kartu Kredit',
        steps: [
          'Klik tombol "Bayar dengan Kartu Kredit"',
          'Isi informasi kartu kredit Anda',
          'Masukkan CVV dan tanggal kadaluarsa',
          'Konfirmasi pembayaran',
          'Tunggu notifikasi pembayaran berhasil'
        ]
      }
    } else if (method === 'cod') {
      return {
        title: 'Instruksi Pembayaran COD',
        steps: [
          'Pesanan Anda akan diproses',
          'Kurir akan mengantarkan pesanan ke alamat Anda',
          'Bayar tunai saat pesanan diterima',
          'Pastikan uang pas untuk mempermudah transaksi'
        ]
      }
    }
    
    return null
  }

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    const notification = document.createElement('div')
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300 ${
      type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
    }`
    notification.innerHTML = `
      <div class="flex items-center gap-2">
        ${type === 'success' ? 
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>' :
          '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>'
        }
        <span>${message}</span>
      </div>
    `
    document.body.appendChild(notification)
    
    // Animate in
    setTimeout(() => {
      notification.classList.remove('translate-x-full')
    }, 100)
    
    // Remove after 3 seconds
    setTimeout(() => {
      notification.classList.add('translate-x-full')
      setTimeout(() => {
        if (document.body.contains(notification)) {
          document.body.removeChild(notification)
        }
      }, 300)
    }, 3000)
  }

  if (!transaction) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400 flex items-center justify-center">
        <div className="text-center">
          <XCircle className="w-24 h-24 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Transaksi Tidak Ditemukan</h2>
          <p className="text-purple-100 mb-6">ID transaksi tidak valid</p>
          <Link to="/orders">
            <Button className="bg-white text-purple-600 hover:bg-purple-50">
              Lihat Pesanan Saya
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  const instructions = getPaymentInstructions()

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Link to="/orders">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-white">Status Pembayaran</h1>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Payment Status Card */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-white flex items-center gap-2">
                  {getStatusIcon(transaction.status)}
                  {getStatusText(transaction.status)}
                </CardTitle>
                <CardDescription className="text-purple-200">
                  ID Transaksi: {transaction.id}
                </CardDescription>
              </div>
              <Badge className={`${getStatusColor(transaction.status)} text-white`}>
                {transaction.status.toUpperCase()}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-white mb-3">Detail Pembayaran</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-purple-200">ID Pesanan</span>
                    <span className="text-white font-mono">{transaction.orderId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-200">Total Pembayaran</span>
                    <span className="text-white">
                      Rp {transaction.amount.toLocaleString('id-ID')}
                    </span>
                  </div>
                  {transaction.expiryDate && (
                    <div className="flex justify-between">
                      <span className="text-purple-200">Batas Pembayaran</span>
                      <span className="text-white">
                        {new Date(transaction.expiryDate).toLocaleString('id-ID')}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Payment Actions */}
              <div className="space-y-3">
                {transaction && transaction.paymentUrl && (
                  <Button 
                    className="w-full bg-white text-purple-600 hover:bg-purple-50"
                    onClick={() => window.open(transaction.paymentUrl, '_blank')}
                  >
                    Bayar Sekarang
                  </Button>
                )}
                
                {transaction && transaction.vaNumber && (
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1 bg-transparent border-white text-white hover:bg-white/20"
                      onClick={() => handleCopyVA(transaction.vaNumber)}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Salin VA
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1 bg-transparent border-white text-white hover:bg-white/20"
                      onClick={handleDownloadQR}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download QR
                    </Button>
                  </div>
                )}
                
                {transaction.paymentMethod === 'credit_card' && (
                  <Button 
                    className="w-full bg-white text-purple-600 hover:bg-purple-50"
                    onClick={() => {
                      // Simulate credit card payment
                      showNotification('Mengarahkan ke halaman pembayaran kartu kredit...', 'success')
                      setTimeout(() => {
                        window.open(transaction.paymentUrl, '_blank')
                      }, 1000)
                    }}
                  >
                    Bayar dengan Kartu Kredit
                  </Button>
                )}
                
                {transaction.paymentMethod === 'cod' && (
                  <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Package className="w-5 h-5 text-yellow-400" />
                      <span className="font-semibold text-white">Pembayaran di Tempat (COD)</span>
                    </div>
                    <p className="text-sm text-yellow-100">
                      Silakan siapkan uang pas saat kurir mengantarkan pesanan Anda. Pesanan akan diproses setelah checkout selesai.
                    </p>
                  </div>
                )}
                
                <div className="text-center">
                  <Button 
                    variant="outline" 
                    className="bg-transparent border-white text-white hover:bg-white/20"
                    onClick={() => navigate('/orders')}
                  >
                    Lihat Status Pesanan
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Instructions */}
        {instructions && (
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
            <CardHeader>
              <CardTitle className="text-white">{instructions.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {instructions.steps.map((step, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-sm font-bold text-white">{index + 1}</span>
                    </div>
                    <p className="text-purple-100">{step}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Order Information */}
        {order && (
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Informasi Pesanan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-purple-200">Status Pesanan</span>
                  <Badge className="bg-blue-500 text-white">
                    {order.orderStatus}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Total Item</span>
                  <span className="text-white">{order.items.length} item</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Alamat Pengiriman</span>
                  <span className="text-white text-right max-w-xs">
                    {order.shippingAddress.address}, {order.shippingAddress.city}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Refresh Button */}
        <div className="text-center mt-6">
          <Button 
            variant="outline" 
            onClick={handleRefreshStatus}
            disabled={paymentLoading}
            className="bg-transparent border-white text-white hover:bg-white/20"
          >
            {paymentLoading ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Memeriksa Status...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Perbarui Status
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
