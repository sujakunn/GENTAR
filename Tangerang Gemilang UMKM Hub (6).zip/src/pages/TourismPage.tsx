
/**
 * Tourism page for UMKM Tangerang Gemilang
 * Features travel recommendations, tourist attractions, and local experiences in Tangerang
 */

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Search, 
  MapPin, 
  Star, 
  Clock, 
  DollarSign, 
  Camera, 
  Mountain, 
  Waves, 
  Building,
  TreePine,
  Utensils,
  ShoppingBag,
  Calendar,
  Heart,
  Share2,
  Navigation,
  Filter,
  TrendingUp,
  Award,
  Users,
  Car,
  Train,
  Plane
} from 'lucide-react'
import Header from '@/components/layout/Header'

interface TourismSpot {
  id: number
  name: string
  category: string
  description: string
  location: string
  rating: number
  reviews: number
  priceRange: string
  openingHours: string
  image: string
  highlights: string[]
  facilities: string[]
  transportation: string[]
  coordinates: string
  bestTime: string
  duration: string
  isPopular: boolean
  isRecommended: boolean
}

export default function TourismPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Semua')
  const [sortBy, setSortBy] = useState('rating')
  const [priceFilter, setPriceFilter] = useState('Semua')

  const categories = [
    'Semua', 'Alam', 'Budaya', 'Sejarah', 'Kuliner', 'Belanja', 'Rekreasi', 'Religi'
  ]

  const priceRanges = [
    { value: 'Semua', label: 'Semua Harga' },
    { value: 'gratis', label: 'Gratis' },
    { value: 'murah', label: 'Rp 5.000 - 25.000' },
    { value: 'sedang', label: 'Rp 25.000 - 50.000' },
    { value: 'mahal', label: 'Rp 50.000+' }
  ]

  const tourismSpots: TourismSpot[] = [
    {
      id: 1,
      name: 'Taman Wisata Alam Situ Cipondoh',
      category: 'Alam',
      description: 'Danau alami yang dikelilingi oleh pepohonan hijau, menawarkan pemandangan yang menenangkan dan udara segar. Tempat yang sempurna untuk piknik, berperahu, dan menikmati matahari terbenam.',
      location: 'Cipondoh, Tangerang',
      rating: 4.7,
      reviews: 1234,
      priceRange: 'Rp 10.000 - 20.000',
      openingHours: '07:00 - 18:00',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/5741e11b-b781-457a-ac31-65f7685166d8.jpg',
      highlights: ['Danau alami', 'Perahu dayung', 'Area piknik', 'Spot foto instagramable'],
      facilities: ['Toilet umum', 'Warung makan', 'Area parkir', 'Mushola'],
      transportation: ['Mobil pribadi', 'Ojek online', 'Angkutan umum'],
      coordinates: '-6.1851, 106.6978',
      bestTime: 'Pagi atau sore hari',
      duration: '2-3 jam',
      isPopular: true,
      isRecommended: true
    },
    {
      id: 2,
      name: 'Masjid Raya Al-Azhom',
      category: 'Religi',
      description: 'Salah satu masjid terbesar dan termegah di Tangerang dengan arsitektur yang memukau. Menjadi pusat keagamaan dan landmark kota yang wajib dikunjungi.',
      location: 'Karawaci, Tangerang',
      rating: 4.8,
      reviews: 2156,
      priceRange: 'Gratis',
      openingHours: '24 jam',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/f6ddcd90-5484-4bb4-89d4-c087d11fe96b.jpg',
      highlights: ['Arsitektur megah', 'Kubah emas', 'Taman hijau', 'Perpustakaan Islam'],
      facilities: ['Parkir luas', 'Toilet', 'Mushola kecil', 'Toko souvenir'],
      transportation: ['Mobil pribadi', 'Transjakarta', 'Ojek online'],
      coordinates: '-6.2144, 106.6302',
      bestTime: 'Setiap saat',
      duration: '1-2 jam',
      isPopular: true,
      isRecommended: true
    },
    {
      id: 3,
      name: 'Tangerang City Mall',
      category: 'Belanja',
      description: 'Pusat perbelanjaan modern dengan berbagai tenant ternama, bioskop, dan area kuliner. Tempat yang sempurna untuk berbelanja, makan, dan hiburan keluarga.',
      location: 'Karawaci, Tangerang',
      rating: 4.5,
      reviews: 3421,
      priceRange: 'Rp 25.000 - 100.000+',
      openingHours: '10:00 - 22:00',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/439d45b8-be60-432b-8c33-aa6461006dc6.jpg',
      highlights: ['Tenant premium', 'Bioskop XXI', 'Food court', 'Area bermain anak'],
      facilities: ['Parkir basement', 'ATM Center', 'Toilet', 'Mushola'],
      transportation: ['Mobil pribadi', 'Transjakarta', 'Ojek online'],
      coordinates: '-6.2144, 106.6302',
      bestTime: 'Sore hingga malam',
      duration: '3-4 jam',
      isPopular: true,
      isRecommended: false
    },
    {
      id: 4,
      name: 'Kampung Naga',
      category: 'Budaya',
      description: 'Desa tradisional yang mempertahankan adat istiadat Sunda. Pengunjung dapat merasakan kehidupan tradisional, arsitektur rumah panggung, dan kuliner autentik.',
      location: 'Neglasari, Tangerang',
      rating: 4.9,
      reviews: 1876,
      priceRange: 'Rp 15.000 - 30.000',
      openingHours: '08:00 - 17:00',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/db224f3b-3f13-4440-a3de-7d53526cdc00.jpg',
      highlights: ['Rumah adat Sunda', 'Budaya tradisional', 'Kuliner autentik', 'Pemandu lokal'],
      facilities: ['Toilet umum', 'Warung makan', 'Area parkir', 'Souvenir shop'],
      transportation: ['Mobil pribadi', 'Ojek online', 'Angkutan desa'],
      coordinates: '-6.2544, 106.5702',
      bestTime: 'Pagi hari',
      duration: '3-4 jam',
      isPopular: true,
      isRecommended: true
    },
    {
      id: 5,
      name: 'Ocean Park BSD',
      category: 'Rekreasi',
      description: 'Taman rekreasi air terbesar di Tangerang dengan berbagai wahana seru. Cocok untuk keluarga dan anak-anak yang ingin bermain air dan menikmati wahana menegangkan.',
      location: 'Serpong, Tangerang',
      rating: 4.6,
      reviews: 4321,
      priceRange: 'Rp 50.000 - 150.000',
      openingHours: '09:00 - 18:00',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/cdc0a70e-e4a0-4ed3-9b89-104b45c65f68.jpg',
      highlights: ['Wahana air', 'Kolam ombak', 'Water slide', 'Area anak'],
      facilities: ['Loker', 'Toilet', 'Ruang ganti', 'Kantin'],
      transportation: ['Mobil pribadi', 'Ojek online', 'Shuttle bus'],
      coordinates: '-6.2984, 106.6702',
      bestTime: 'Sepanjang hari',
      duration: '4-5 jam',
      isPopular: true,
      isRecommended: true
    },
    {
      id: 6,
      name: 'Pasar Lama Tangerang',
      category: 'Kuliner',
      description: 'Pusat kuliner legendaris di Tangerang dengan berbagai makanan tradisional dan modern. Surga bagi para pecinta kuliner yang ingin mencicipi hidangan otentik.',
      location: 'Tangerang, Tangerang',
      rating: 4.4,
      reviews: 2876,
      priceRange: 'Rp 5.000 - 50.000',
      openingHours: '16:00 - 24:00',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/fbf4ea64-bba9-4b44-8935-42a6751bfa0f.jpg',
      highlights: ['Street food', 'Makanan tradisional', 'Atmosfer vintage', 'Live music'],
      facilities: ['Area duduk', 'Toilet', 'Parkir sepeda motor', 'Keamanan'],
      transportation: ['Mobil pribadi', 'Ojek online', 'Becak'],
      coordinates: '-6.1784, 106.6302',
      bestTime: 'Malam hari',
      duration: '2-3 jam',
      isPopular: true,
      isRecommended: true
    },
    {
      id: 7,
      name: 'Benteng Heritage',
      category: 'Sejarah',
      description: 'Situs bersejarah peninggalan Belanda yang menjadi saksi bisu perjuangan bangsa. Menawarkan wisata edukatif dengan arsitektur kolonial yang terawat.',
      location: 'Tangerang, Tangerang',
      rating: 4.3,
      reviews: 1234,
      priceRange: 'Rp 5.000 - 15.000',
      openingHours: '08:00 - 16:00',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/6f963f90-be09-45e7-96dc-43d8591a4657.jpg',
      highlights: ['Arsitektur kolonial', 'Museum sejarah', 'Area foto', 'Pemandu wisata'],
      facilities: ['Toilet', 'Museum shop', 'Area parkir', 'Cafetaria'],
      transportation: ['Mobil pribadi', 'Ojek online', 'Angkutan kota'],
      coordinates: '-6.1784, 106.6302',
      bestTime: 'Pagi hari',
      duration: '1-2 jam',
      isPopular: false,
      isRecommended: true
    },
    {
      id: 8,
      name: 'Scientia Square Park',
      category: 'Rekreasi',
      description: 'Taman kota modern dengan area hijau luas, jogging track, dan berbagai fasilitas rekreasi. Tempat yang sempurna untuk olahraga, piknik, dan kegiatan outdoor.',
      location: 'Serpong, Tangerang',
      rating: 4.5,
      reviews: 1987,
      priceRange: 'Gratis',
      openingHours: '06:00 - 22:00',
      image: 'https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/6f5c657e-e898-4ea8-8a2b-cc3a245e0a9b.jpg',
      highlights: ['Taman hijau', 'Jogging track', 'Area bermain', 'Danau buatan'],
      facilities: ['Toilet umum', 'Food court', 'Area parkir', 'Free WiFi'],
      transportation: ['Mobil pribadi', 'Ojek online', 'Transjakarta'],
      coordinates: '-6.2984, 106.6702',
      bestTime: 'Pagi atau sore hari',
      duration: '2-3 jam',
      isPopular: true,
      isRecommended: true
    }
  ]

  const filteredSpots = tourismSpots.filter(spot => {
    const matchesSearch = spot.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         spot.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         spot.location.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'Semua' || spot.category === selectedCategory
    const matchesPrice = priceFilter === 'Semua' || 
                          (priceFilter === 'gratis' && spot.priceRange.includes('Gratis')) ||
                          (priceFilter === 'murah' && spot.priceRange.includes('Rp 10.000')) ||
                          (priceFilter === 'sedang' && spot.priceRange.includes('Rp 25.000')) ||
                          (priceFilter === 'mahal' && spot.priceRange.includes('Rp 50.000'))
    
    return matchesSearch && matchesCategory && matchesPrice
  })

  const sortedSpots = [...filteredSpots].sort((a, b) => {
    switch (sortBy) {
      case 'rating':
        return b.rating - a.rating
      case 'name':
        return a.name.localeCompare(b.name)
      case 'price':
        return a.priceRange.localeCompare(b.priceRange)
      case 'popular':
        return b.reviews - a.reviews
      default:
        return 0
    }
  })

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Alam': return <TreePine className="w-5 h-5" />
      case 'Budaya': return <Building className="w-5 h-5" />
      case 'Sejarah': return <Award className="w-5 h-5" />
      case 'Kuliner': return <Utensils className="w-5 h-5" />
      case 'Belanja': return <ShoppingBag className="w-5 h-5" />
      case 'Rekreasi': return <Waves className="w-5 h-5" />
      case 'Religi': return <Star className="w-5 h-5" />
      default: return <MapPin className="w-5 h-5" />
    }
  }

  const getPriceColor = (priceRange: string) => {
    if (priceRange.includes('Gratis')) return 'bg-green-500'
    if (priceRange.includes('Rp 5.000')) return 'bg-blue-500'
    if (priceRange.includes('Rp 25.000')) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  const getTransportIcon = (transport: string) => {
    if (transport.includes('Mobil')) return <Car className="w-4 h-4" />
    if (transport.includes('Transjakarta')) return <Train className="w-4 h-4" />
    if (transport.includes('Ojek')) return <Navigation className="w-4 h-4" />
    return <Plane className="w-4 h-4" />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Jelajahi Keindahan Tangerang
          </h2>
          <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
            Temukan destinasi wisata menakjubkan, pengalaman kuliner autentik, dan warisan budaya yang kaya di Tangerang
          </p>
          
          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto mb-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">50+</div>
              <div className="text-purple-100">Destinasi Wisata</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">1M+</div>
              <div className="text-purple-100">Pengunjung Tahunan</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">4.8</div>
              <div className="text-purple-100">Rating Rata-rata</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-purple-50">
              <MapPin className="w-5 h-5 mr-2" />
              Jelajahi Sekarang
            </Button>
            <Button variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white/20">
              <Camera className="w-5 h-5 mr-2" />
              Buat Itinerary
            </Button>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-200 w-5 h-5" />
              <Input
                placeholder="Cari destinasi wisata..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/20 border-white/30 text-white placeholder-purple-200 focus:bg-white/30"
              />
            </div>
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-6">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={`${selectedCategory === category 
                  ? "bg-white text-purple-600" 
                  : "bg-transparent border-white text-white hover:bg-white/20"
                }`}
              >
                {getCategoryIcon(category)}
                <span className="ml-2">{category}</span>
              </Button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <span className="text-white">Urutkan:</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40 bg-white/20 border-white/30 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">Rating Tertinggi</SelectItem>
                <SelectItem value="name">Nama A-Z</SelectItem>
                <SelectItem value="price">Harga Termurah</SelectItem>
                <SelectItem value="popular">Paling Populer</SelectItem>
              </SelectContent>
            </Select>
            
            <span className="text-white ml-4">Harga:</span>
            <Select value={priceFilter} onValueChange={setPriceFilter}>
              <SelectTrigger className="w-40 bg-white/20 border-white/30 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {priceRanges.map((range) => (
                  <SelectItem key={range.value} value={range.value}>
                    {range.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">Destinasi Unggulan</h2>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400">Populer</span>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tourismSpots
              .filter(spot => spot.isPopular && spot.isRecommended)
              .slice(0, 3)
              .map((spot) => (
                <Card key={spot.id} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105 overflow-hidden">
                  <div className="relative">
                    <div className="h-56 bg-gradient-to-r from-purple-500 to-cyan-400 relative">
                      <div className="absolute top-4 right-4 flex gap-2">
                        {spot.isRecommended && (
                          <Badge className="bg-yellow-500 text-white">
                            <Award className="w-3 h-3 mr-1" />
                            Rekomendasi
                          </Badge>
                        )}
                        {spot.isPopular && (
                          <Badge className="bg-red-500 text-white">
                            <TrendingUp className="w-3 h-3 mr-1" />
                            Populer
                          </Badge>
                        )}
                      </div>
                      <div className="absolute bottom-4 left-4">
                        <Badge className="bg-white/20 text-white">
                          {getCategoryIcon(spot.category)}
                          <span className="ml-2">{spot.category}</span>
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-white mb-2">{spot.name}</h3>
                        <div className="flex items-center gap-2 text-purple-200 mb-2">
                          <MapPin className="w-4 h-4" />
                          <span className="text-sm">{spot.location}</span>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-white">{spot.rating}</span>
                            <span className="text-purple-200">({spot.reviews})</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4 text-purple-200" />
                            <span className="text-purple-200">{spot.duration}</span>
                          </div>
                        </div>
                      </div>
                      <Badge className={`${getPriceColor(spot.priceRange)} text-white`}>
                        {spot.priceRange}
                      </Badge>
                    </div>
                    
                    <p className="text-purple-100 text-sm mb-4 line-clamp-2">{spot.description}</p>
                    
                    <div className="flex flex-wrap gap-1 mb-4">
                      {spot.highlights.slice(0, 3).map((highlight, idx) => (
                        <Badge key={idx} variant="secondary" className="bg-purple-500/20 text-purple-200 text-xs">
                          {highlight}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button className="flex-1 bg-white text-purple-600 hover:bg-purple-50">
                        <MapPin className="w-4 h-4 mr-2" />
                        Kunjungi
                      </Button>
                      <Button variant="outline" size="icon" className="bg-transparent border-white text-white hover:bg-white/20">
                        <Heart className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="bg-transparent border-white text-white hover:bg-white/20">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      </section>

      {/* All Destinations */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">
              {selectedCategory === 'Semua' ? 'Semua Destinasi' : `Destinasi ${selectedCategory}`}
            </h2>
            <span className="text-purple-100">{sortedSpots.length} destinasi ditemukan</span>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedSpots.map((spot) => (
              <Card key={spot.id} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105 overflow-hidden">
                <div className="relative">
                  <div className="h-48 bg-gradient-to-r from-purple-500 to-cyan-400 relative">
                    <div className="absolute top-4 right-4 flex gap-2">
                      {spot.isRecommended && (
                        <Badge className="bg-yellow-500 text-white">
                          <Award className="w-3 h-3 mr-1" />
                          Rekomendasi
                        </Badge>
                      )}
                      {spot.isPopular && (
                        <Badge className="bg-red-500 text-white">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          Populer
                        </Badge>
                      )}
                    </div>
                    <div className="absolute bottom-4 left-4">
                      <Badge className="bg-white/20 text-white">
                        {getCategoryIcon(spot.category)}
                        <span className="ml-2">{spot.category}</span>
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-white mb-2">{spot.name}</h3>
                      <div className="flex items-center gap-2 text-purple-200 mb-2">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">{spot.location}</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-white">{spot.rating}</span>
                          <span className="text-purple-200">({spot.reviews})</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4 text-purple-200" />
                          <span className="text-purple-200">{spot.duration}</span>
                        </div>
                      </div>
                    </div>
                    <Badge className={`${getPriceColor(spot.priceRange)} text-white`}>
                      {spot.priceRange}
                    </Badge>
                  </div>
                  
                  <p className="text-purple-100 text-sm mb-4 line-clamp-2">{spot.description}</p>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center gap-2 text-sm text-purple-200">
                      <Calendar className="w-4 h-4" />
                      <span>Buka: {spot.openingHours}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-purple-200">
                      <Users className="w-4 h-4" />
                      <span>Terbaik: {spot.bestTime}</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-4">
                    {spot.highlights.slice(0, 2).map((highlight, idx) => (
                      <Badge key={idx} variant="secondary" className="bg-purple-500/20 text-purple-200 text-xs">
                        {highlight}
                      </Badge>
                    ))}
                    {spot.highlights.length > 2 && (
                      <Badge variant="secondary" className="bg-purple-500/20 text-purple-200 text-xs">
                        +{spot.highlights.length - 2}
                      </Badge>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-white text-purple-600 hover:bg-purple-50">
                      <MapPin className="w-4 h-4 mr-2" />
                      Detail
                    </Button>
                    <Button variant="outline" size="icon" className="bg-transparent border-white text-white hover:bg-white/20">
                      <Heart className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="icon" className="bg-transparent border-white text-white hover:bg-white/20">
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {sortedSpots.length === 0 && (
            <div className="text-center py-12">
              <MapPin className="w-16 h-16 text-purple-200 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Destinasi tidak ditemukan</h3>
              <p className="text-purple-100">Coba kata kunci pencarian lain atau kategori berbeda</p>
            </div>
          )}
        </div>
      </section>

      {/* Travel Tips Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">Tips Wisata Tangerang</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <Car className="w-8 h-8" />,
                title: "Transportasi",
                description: "Gunakan Transjakarta atau ojek online untuk kemudahan akses ke berbagai destinasi"
              },
              {
                icon: <Clock className="w-8 h-8" />,
                title: "Waktu Terbaik",
                description: "Kunjungi destinasi alam di pagi hari dan wisata belanja di sore hingga malam"
              },
              {
                icon: <DollarSign className="w-8 h-8" />,
                title: "Anggaran",
                description: "Bawa uang tunai secukupnya, beberapa tempat mungkin tidak menerima pembayaran digital"
              },
              {
                icon: <Camera className="w-8 h-8" />,
                title: "Dokumentasi",
                description: "Bawa kamera dan power bank untuk mengabadikan momen indah selama perjalanan"
              }
            ].map((tip, index) => (
              <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 text-white">
                    {tip.icon}
                  </div>
                  <h3 className="font-semibold text-white mb-2">{tip.title}</h3>
                  <p className="text-sm text-purple-100">{tip.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl font-bold text-white mb-4">Rencanakan Perjalanan Anda</h3>
          <p className="text-lg text-purple-100 mb-6">
            Buat itinerary pribadi, dapatkan rekomendasi tempat menginap, dan nikmati pengalaman wisata terbaik di Tangerang
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-purple-50">
              <Calendar className="w-5 h-5 mr-2" />
              Buat Rencana Perjalanan
            </Button>
            <Button variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white/20">
              <Users className="w-5 h-5 mr-2" />
              Cari Pemandu Wisata
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
