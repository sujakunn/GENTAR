/**
 * Homepage for UMKM Tangerang Gemilang Marketplace
 * Features navigation to About, Marketplace, Community, and Training sections
 */

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ShoppingCart, Users, GraduationCap, Info, Menu, X, MapPin, TreePine, Building, Utensils } from 'lucide-react'
import { Link } from 'react-router'
import Header from '@/components/layout/Header'

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  // Test function
  const testFunction = () => {
    console.log('Home page loaded successfully')
    console.log('Mobile menu open:', mobileMenuOpen)
  }
  
  // Call test function on mount
  useState(() => {
    testFunction()
  })

  // Navigation items
  const navItems = [
    { name: 'Tentang', icon: Info, href: '/about' },
    { name: 'Marketplace', icon: ShoppingCart, href: '/marketplace' },
    { name: 'Komunitas', icon: Users, href: '/community' },
    { name: 'Pelatihan', icon: GraduationCap, href: '/training' },
    { name: 'Wisata', icon: MapPin, href: '/tourism' },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-cyan-400">
      {/* Navigation */}
      <Header />

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Wujudkan Impian Usaha Anda Bersama UMKM Tangerang Gemilang
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Platform digital untuk mengembangkan UMKM, memperluas jangkauan pasar, dan membangun komunitas yang kuat
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/auth">
              <Button size="lg" className="bg-white text-purple-600 hover:bg-purple-50">
                Mulai Berjualan
              </Button>
            </Link>
            <Link to="/about">
              <Button variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white/20">
                Pelajari Lebih Lanjut
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Tentang Kami</h2>
            <p className="text-lg text-purple-100 max-w-3xl mx-auto">
              UMKM Tangerang Gemilang adalah inisiatif untuk mendukung pengembangan usaha mikro, kecil, dan menengah di wilayah Tangerang melalui platform digital terintegrasi.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingCart className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Marketplace Digital</h3>
              <p className="text-purple-100">Platform jual beli produk UMKM dengan jangkauan luas dan sistem pembayaran aman.</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Komunitas Solid</h3>
              <p className="text-purple-100">Wadah untuk berbagi pengalaman, kolaborasi, dan dukungan antar pelaku UMKM.</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Pelatihan Berkualitas</h3>
              <p className="text-purple-100">Program pengembangan kapasitas untuk meningkatkan kompetensi wirausaha.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Marketplace Section */}
      <section id="marketplace" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Marketplace</h2>
            <p className="text-lg text-purple-100">Temukan berbagai produk unggulan dari UMKM Tangerang</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Product cards */}
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                <img 
                  src={`https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/c000bce2-6711-4af0-ace2-d0215e6939b7.jpg`} 
                  alt={`Product ${item}`}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-gray-800 mb-2">Produk Unggulan {item}</h3>
                  <p className="text-gray-600 text-sm mb-3">Deskripsi singkat produk UMKM berkualitas</p>
                  <div className="flex justify-between items-center">
                    <span className="text-purple-600 font-bold">Rp 50.000</span>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                      Beli
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
              <Link to="/marketplace" className="text-white hover:text-purple-200">
                Lihat Semua Produk
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section id="community" className="py-16 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Komunitas</h2>
            <p className="text-lg text-purple-100">Bergabung dengan komunitas UMKM Tangerang yang solid</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-semibold text-white mb-4">Aktivitas Terkini</h3>
              <div className="space-y-4">
                {[1, 2, 3].map((item) => (
                  <div key={item} className="bg-white/10 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                        <Users className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-white">Kegiatan Komunitas {item}</h4>
                        <p className="text-purple-100 text-sm">Diskusi tentang pengembangan usaha dan strategi pemasaran</p>
                        <span className="text-purple-200 text-xs">2 jam yang lalu</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-semibold text-white mb-4">Forum Diskusi</h3>
              <div className="space-y-4">
                {[1, 2].map((item) => (
                  <div key={item} className="bg-white/10 rounded-lg p-4">
                    <h4 className="font-medium text-white mb-2">Topik Diskusi {item}</h4>
                    <p className="text-purple-100 text-sm mb-2">Bagaimana meningkatkan penjualan online?</p>
                    <div className="flex items-center gap-4 text-purple-200 text-sm">
                      <span>15 komentar</span>
                      <span>234 anggota</span>
                    </div>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-4 bg-white text-purple-600 hover:bg-purple-50">
                <Link to="/community" className="text-purple-600 hover:text-purple-700">
                  Bergabung Sekarang
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Training Section */}
      <section id="training" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Pelatihan</h2>
            <p className="text-lg text-purple-100">Kembangkan kompetensi Anda melalui program pelatihan kami</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((item) => (
              <div key={item} className="bg-white rounded-lg overflow-hidden shadow-lg">
                <img 
                  src={`https://pub-cdn.sider.ai/u/U0X7H89J8KV/web-coder/68b927cd38697d89a159e250/resource/46206434-18b3-47cc-8486-d87e3ef15947.jpg`} 
                  alt={`Training ${item}`}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <GraduationCap className="w-5 h-5 text-purple-600" />
                    <span className="text-purple-600 font-medium">Pelatihan {item}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    {item === 1 ? 'Digital Marketing' : item === 2 ? 'Manajemen Keuangan' : 'Branding & Packaging'}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {item === 1 ? 'Pelajari strategi pemasaran digital untuk meningkatkan penjualan online.' : 
                     item === 2 ? 'Kelola keuangan usaha dengan baik untuk pertumbuhan yang berkelanjutan.' : 
                     'Ciptakan identitas brand yang kuat dan kemasan yang menarik.'}
                  </p>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-gray-500">Durasi: 8 sesi</span>
                    <span className="text-sm text-gray-500">Mulai: 15/{item + 9}/2024</span>
                  </div>
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">
                    Daftar Sekarang
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
              <Link to="/training" className="text-white hover:text-purple-200">
                Lihat Semua Pelatihan
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Tourism Section */}
      <section id="tourism" className="py-16 px-4 sm:px-6 lg:px-8 bg-white/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Wisata Tangerang</h2>
            <p className="text-lg text-purple-100 max-w-3xl mx-auto">
              Jelajahi keindahan alam, warisan budaya, dan destinasi menarik di Tangerang
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Alam & Rekreasi',
                description: 'Danau, taman, dan destinasi alam yang memukau',
                icon: <TreePine className="w-8 h-8 text-white" />
              },
              {
                title: 'Budaya & Sejarah',
                description: 'Warisan budaya dan situs bersejarah yang kaya',
                icon: <Building className="w-8 h-8 text-white" />
              },
              {
                title: 'Kuliner & Belanja',
                description: 'Wisata kuliner autentik dan pusat perbelanjaan modern',
                icon: <Utensils className="w-8 h-8 text-white" />
              }
            ].map((item, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center hover:bg-white/20 transition-colors">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  {item.icon}
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-purple-100">{item.description}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Link to="/tourism">
              <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
                Jelajahi Semua Destinasi
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/20 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-white mb-4">UMKM Tangerang Gemilang</h3>
            <p className="text-purple-100 mb-4">Membangun ekonomi lokal melalui digitalisasi UMKM</p>
            <div className="flex justify-center space-x-6">
              <Link to="/about" className="text-purple-200 hover:text-white">Tentang</Link>
              <Link to="/marketplace" className="text-purple-200 hover:text-white">Marketplace</Link>
              <Link to="/community" className="text-purple-200 hover:text-white">Komunitas</Link>
              <Link to="/training" className="text-purple-200 hover:text-white">Pelatihan</Link>
              <Link to="/tourism" className="text-purple-200 hover:text-white">Wisata</Link>
              <Link to="/auth" className="text-purple-200 hover:text-white">Masuk</Link>
            </div>
            <p className="text-purple-200 text-sm mt-4">© 2024 UMKM Tangerang Gemilang. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}